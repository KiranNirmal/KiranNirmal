Imports Google.Apis.Auth.OAuth2
Imports Google.Apis.Sheets.v4
Imports Google.Apis.Sheets.v4.Data
Imports Google.Apis.Services
Imports Google.Apis.Util.Store
Imports System
Imports System.Collections.Generic
Imports System.IO
Imports System.Threading
Friend Class Program
    ' If modifying these scopes, delete your previously saved credentials
    ' at ~/.credentials/sheets.googleapis.com-dotnet-quickstart.json
    Private Shared Scopes() As String = {SheetsService.Scope.SpreadsheetsReadonly}
    Private Shared ApplicationName As String = "Google Sheets API .NET Quickstart"

    Shared Sub Main(ByVal args() As String)
        Dim credential As UserCredential

        Using stream = New FileStream("credentials.json", FileMode.Open, FileAccess.Read)
            Dim credPath As String = "token.json"
            credential = GoogleWebAuthorizationBroker.AuthorizeAsync(GoogleClientSecrets.Load(stream).Secrets, Scopes, "user", CancellationToken.None, New FileDataStore(credPath, True)).Result
            Console.WriteLine("Credential file saved to: " & credPath)
        End Using

        ' Create Google Sheets API service.
        Dim service = New SheetsService(New BaseClientService.Initializer() With {
                     .HttpClientInitializer = credential,
                     .ApplicationName = ApplicationName
            })

        ' Define request parameters.
        Dim spreadsheetId As String = "13RVKMCA3mTST2o8zMb9iTpnFBAw6b41bh-KUrcBV84Y"
        Dim range As String = "A2:B64"
        Dim request As SpreadsheetsResource.ValuesResource.GetRequest = service.Spreadsheets.Values.Get(spreadsheetId, range)

        ' Prints the names and majors of students in a sample spreadsheet:
        ' https://docs.google.com/spreadsheets/d/1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms/edit
        Dim response As ValueRange = request.Execute()
        Dim values As IList(Of IList(Of Object)) = response.Values
        If values IsNot Nothing AndAlso values.Count > 0 Then

            For Each row In values
                Try
                    Console.WriteLine("ROW DATA:---->" + row(0) + "=" + row(1))
                Catch ex As Exception

                End Try
                ' Print columns A and E, which correspond to indices 0 and 4.

            Next row
        Else
            Console.WriteLine("No data found.")
        End If
        Console.Read()
    End Sub
End Class
