﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProgramTrading
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.AddStrategyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ModifyStrategyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeleteStrategyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
        Me.StartStrategyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UpdateStrategyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PauseStrategyCtrlPToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StopStrategyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SquareoffStrategyCtrlQToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShowJobbingStatusToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem5 = New System.Windows.Forms.ToolStripSeparator()
        Me.ParticularAccountToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StartStrategiesPAccountToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StopStrategiesPAccountToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeleteStrategiesPAccountToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SquareOffStrategiesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ParticularScripToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StartStrategiesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StopStrategiesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeleteStrategiesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SquareOffStrategiesToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripSeparator()
        Me.OthersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoveExecutingStrategyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripSeparator()
        Me.ImportFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripSeparator()
        Me.StrategyVersionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveWatchlistToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.timer_SlowUpdate = New System.Windows.Forms.Timer(Me.components)
        Me.panel_StartStrategy = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.panelOne = New System.Windows.Forms.Panel()
        Me.cmb_Acc = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.browseFile = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.link_StartExecution = New System.Windows.Forms.LinkLabel()
        Me.ContextMenuStrip2 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.MarkAsLevelExecutedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MarkAsTargetTradedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MarkAsNotExecutedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.col_Pos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DGV = New QuantX.CustomDGView()
        Me.col_On = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.col_SID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Status = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Scrip = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_LTP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Quantity = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Side = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Account = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Price = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_DES = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.panel_StartStrategy.SuspendLayout()
        Me.panelOne.SuspendLayout()
        Me.ContextMenuStrip2.SuspendLayout()
        CType(Me.DGV, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddStrategyToolStripMenuItem, Me.ModifyStrategyToolStripMenuItem, Me.DeleteStrategyToolStripMenuItem, Me.ToolStripMenuItem1, Me.StartStrategyToolStripMenuItem, Me.UpdateStrategyToolStripMenuItem, Me.PauseStrategyCtrlPToolStripMenuItem, Me.StopStrategyToolStripMenuItem, Me.SquareoffStrategyCtrlQToolStripMenuItem, Me.ShowJobbingStatusToolStripMenuItem, Me.ToolStripMenuItem5, Me.ParticularAccountToolStripMenuItem, Me.ParticularScripToolStripMenuItem, Me.ToolStripMenuItem2, Me.OthersToolStripMenuItem, Me.SaveWatchlistToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(232, 308)
        '
        'AddStrategyToolStripMenuItem
        '
        Me.AddStrategyToolStripMenuItem.Name = "AddStrategyToolStripMenuItem"
        Me.AddStrategyToolStripMenuItem.Size = New System.Drawing.Size(231, 22)
        Me.AddStrategyToolStripMenuItem.Text = "Add Strategy (Ctrl + A)"
        '
        'ModifyStrategyToolStripMenuItem
        '
        Me.ModifyStrategyToolStripMenuItem.Name = "ModifyStrategyToolStripMenuItem"
        Me.ModifyStrategyToolStripMenuItem.Size = New System.Drawing.Size(231, 22)
        Me.ModifyStrategyToolStripMenuItem.Text = "Modify Strategy (Ctrl + M)"
        '
        'DeleteStrategyToolStripMenuItem
        '
        Me.DeleteStrategyToolStripMenuItem.Name = "DeleteStrategyToolStripMenuItem"
        Me.DeleteStrategyToolStripMenuItem.Size = New System.Drawing.Size(231, 22)
        Me.DeleteStrategyToolStripMenuItem.Text = "Delete Strategy (Del)"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(228, 6)
        '
        'StartStrategyToolStripMenuItem
        '
        Me.StartStrategyToolStripMenuItem.Name = "StartStrategyToolStripMenuItem"
        Me.StartStrategyToolStripMenuItem.Size = New System.Drawing.Size(231, 22)
        Me.StartStrategyToolStripMenuItem.Text = "Start Strategy (Ctrl+N)"
        '
        'UpdateStrategyToolStripMenuItem
        '
        Me.UpdateStrategyToolStripMenuItem.Name = "UpdateStrategyToolStripMenuItem"
        Me.UpdateStrategyToolStripMenuItem.Size = New System.Drawing.Size(231, 22)
        Me.UpdateStrategyToolStripMenuItem.Text = "Update Values (Ctrl + S)"
        '
        'PauseStrategyCtrlPToolStripMenuItem
        '
        Me.PauseStrategyCtrlPToolStripMenuItem.Name = "PauseStrategyCtrlPToolStripMenuItem"
        Me.PauseStrategyCtrlPToolStripMenuItem.Size = New System.Drawing.Size(231, 22)
        Me.PauseStrategyCtrlPToolStripMenuItem.Text = "Pause Strategy (Ctrl + P)"
        '
        'StopStrategyToolStripMenuItem
        '
        Me.StopStrategyToolStripMenuItem.Name = "StopStrategyToolStripMenuItem"
        Me.StopStrategyToolStripMenuItem.Size = New System.Drawing.Size(231, 22)
        Me.StopStrategyToolStripMenuItem.Text = "Stop Strategy (Ctrl + R)"
        '
        'SquareoffStrategyCtrlQToolStripMenuItem
        '
        Me.SquareoffStrategyCtrlQToolStripMenuItem.Name = "SquareoffStrategyCtrlQToolStripMenuItem"
        Me.SquareoffStrategyCtrlQToolStripMenuItem.Size = New System.Drawing.Size(231, 22)
        Me.SquareoffStrategyCtrlQToolStripMenuItem.Text = "Squareoff Strategy (Ctrl + Q)"
        '
        'ShowJobbingStatusToolStripMenuItem
        '
        Me.ShowJobbingStatusToolStripMenuItem.Name = "ShowJobbingStatusToolStripMenuItem"
        Me.ShowJobbingStatusToolStripMenuItem.Size = New System.Drawing.Size(231, 22)
        Me.ShowJobbingStatusToolStripMenuItem.Text = "Show Jobbing Status (Ctrl + J)"
        '
        'ToolStripMenuItem5
        '
        Me.ToolStripMenuItem5.Name = "ToolStripMenuItem5"
        Me.ToolStripMenuItem5.Size = New System.Drawing.Size(228, 6)
        '
        'ParticularAccountToolStripMenuItem
        '
        Me.ParticularAccountToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StartStrategiesPAccountToolStripMenuItem, Me.StopStrategiesPAccountToolStripMenuItem, Me.DeleteStrategiesPAccountToolStripMenuItem, Me.SquareOffStrategiesToolStripMenuItem})
        Me.ParticularAccountToolStripMenuItem.Name = "ParticularAccountToolStripMenuItem"
        Me.ParticularAccountToolStripMenuItem.Size = New System.Drawing.Size(231, 22)
        Me.ParticularAccountToolStripMenuItem.Text = "Particular Account"
        '
        'StartStrategiesPAccountToolStripMenuItem
        '
        Me.StartStrategiesPAccountToolStripMenuItem.Name = "StartStrategiesPAccountToolStripMenuItem"
        Me.StartStrategiesPAccountToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.StartStrategiesPAccountToolStripMenuItem.Text = "Start Strategies"
        '
        'StopStrategiesPAccountToolStripMenuItem
        '
        Me.StopStrategiesPAccountToolStripMenuItem.Name = "StopStrategiesPAccountToolStripMenuItem"
        Me.StopStrategiesPAccountToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.StopStrategiesPAccountToolStripMenuItem.Text = "Stop Strategies"
        '
        'DeleteStrategiesPAccountToolStripMenuItem
        '
        Me.DeleteStrategiesPAccountToolStripMenuItem.Name = "DeleteStrategiesPAccountToolStripMenuItem"
        Me.DeleteStrategiesPAccountToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.DeleteStrategiesPAccountToolStripMenuItem.Text = "Delete Strategies"
        '
        'SquareOffStrategiesToolStripMenuItem
        '
        Me.SquareOffStrategiesToolStripMenuItem.Name = "SquareOffStrategiesToolStripMenuItem"
        Me.SquareOffStrategiesToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.SquareOffStrategiesToolStripMenuItem.Text = "SquareOff Strategies"
        '
        'ParticularScripToolStripMenuItem
        '
        Me.ParticularScripToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StartStrategiesToolStripMenuItem, Me.StopStrategiesToolStripMenuItem, Me.DeleteStrategiesToolStripMenuItem, Me.SquareOffStrategiesToolStripMenuItem1})
        Me.ParticularScripToolStripMenuItem.Name = "ParticularScripToolStripMenuItem"
        Me.ParticularScripToolStripMenuItem.Size = New System.Drawing.Size(231, 22)
        Me.ParticularScripToolStripMenuItem.Text = "Particular Scrip"
        '
        'StartStrategiesToolStripMenuItem
        '
        Me.StartStrategiesToolStripMenuItem.Name = "StartStrategiesToolStripMenuItem"
        Me.StartStrategiesToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.StartStrategiesToolStripMenuItem.Text = "Start Strategies"
        '
        'StopStrategiesToolStripMenuItem
        '
        Me.StopStrategiesToolStripMenuItem.Name = "StopStrategiesToolStripMenuItem"
        Me.StopStrategiesToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.StopStrategiesToolStripMenuItem.Text = "Stop Strategies"
        '
        'DeleteStrategiesToolStripMenuItem
        '
        Me.DeleteStrategiesToolStripMenuItem.Name = "DeleteStrategiesToolStripMenuItem"
        Me.DeleteStrategiesToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.DeleteStrategiesToolStripMenuItem.Text = "Delete Strategies"
        '
        'SquareOffStrategiesToolStripMenuItem1
        '
        Me.SquareOffStrategiesToolStripMenuItem1.Name = "SquareOffStrategiesToolStripMenuItem1"
        Me.SquareOffStrategiesToolStripMenuItem1.Size = New System.Drawing.Size(181, 22)
        Me.SquareOffStrategiesToolStripMenuItem1.Text = "SquareOff Strategies"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(228, 6)
        '
        'OthersToolStripMenuItem
        '
        Me.OthersToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RemoveExecutingStrategyToolStripMenuItem, Me.ToolStripMenuItem3, Me.ImportFileToolStripMenuItem, Me.ToolStripMenuItem4, Me.StrategyVersionToolStripMenuItem})
        Me.OthersToolStripMenuItem.Name = "OthersToolStripMenuItem"
        Me.OthersToolStripMenuItem.Size = New System.Drawing.Size(231, 22)
        Me.OthersToolStripMenuItem.Text = "Others"
        '
        'RemoveExecutingStrategyToolStripMenuItem
        '
        Me.RemoveExecutingStrategyToolStripMenuItem.Name = "RemoveExecutingStrategyToolStripMenuItem"
        Me.RemoveExecutingStrategyToolStripMenuItem.Size = New System.Drawing.Size(262, 22)
        Me.RemoveExecutingStrategyToolStripMenuItem.Text = "Remove Executing Strategy (Ctrl+Z)"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(259, 6)
        '
        'ImportFileToolStripMenuItem
        '
        Me.ImportFileToolStripMenuItem.Name = "ImportFileToolStripMenuItem"
        Me.ImportFileToolStripMenuItem.Size = New System.Drawing.Size(262, 22)
        Me.ImportFileToolStripMenuItem.Text = "Import File for New Strategy"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(259, 6)
        '
        'StrategyVersionToolStripMenuItem
        '
        Me.StrategyVersionToolStripMenuItem.Name = "StrategyVersionToolStripMenuItem"
        Me.StrategyVersionToolStripMenuItem.Size = New System.Drawing.Size(262, 22)
        Me.StrategyVersionToolStripMenuItem.Text = "Strategy Version"
        '
        'SaveWatchlistToolStripMenuItem
        '
        Me.SaveWatchlistToolStripMenuItem.Name = "SaveWatchlistToolStripMenuItem"
        Me.SaveWatchlistToolStripMenuItem.Size = New System.Drawing.Size(231, 22)
        Me.SaveWatchlistToolStripMenuItem.Text = "Save Watchlist"
        '
        'timer_SlowUpdate
        '
        Me.timer_SlowUpdate.Interval = 500
        '
        'panel_StartStrategy
        '
        Me.panel_StartStrategy.BackColor = System.Drawing.Color.LightGray
        Me.panel_StartStrategy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panel_StartStrategy.Controls.Add(Me.panelOne)
        Me.panel_StartStrategy.Controls.Add(Me.Label3)
        Me.panel_StartStrategy.Controls.Add(Me.link_StartExecution)
        Me.panel_StartStrategy.Dock = System.Windows.Forms.DockStyle.Top
        Me.panel_StartStrategy.Location = New System.Drawing.Point(0, 0)
        Me.panel_StartStrategy.Name = "panel_StartStrategy"
        Me.panel_StartStrategy.Size = New System.Drawing.Size(612, 71)
        Me.panel_StartStrategy.TabIndex = 100
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(675, 7)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(119, 16)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Strategy Execution"
        Me.Label1.Visible = False
        '
        'LinkLabel1
        '
        Me.LinkLabel1.ActiveLinkColor = System.Drawing.Color.Blue
        Me.LinkLabel1.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel1.Location = New System.Drawing.Point(675, 34)
        Me.LinkLabel1.Margin = New System.Windows.Forms.Padding(0, 0, 3, 0)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(122, 17)
        Me.LinkLabel1.TabIndex = 2
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Click here"
        Me.LinkLabel1.Visible = False
        '
        'panelOne
        '
        Me.panelOne.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.panelOne.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panelOne.Controls.Add(Me.Label1)
        Me.panelOne.Controls.Add(Me.cmb_Acc)
        Me.panelOne.Controls.Add(Me.LinkLabel1)
        Me.panelOne.Controls.Add(Me.Label4)
        Me.panelOne.Controls.Add(Me.Label2)
        Me.panelOne.Controls.Add(Me.browseFile)
        Me.panelOne.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelOne.Location = New System.Drawing.Point(0, 0)
        Me.panelOne.Name = "panelOne"
        Me.panelOne.Size = New System.Drawing.Size(610, 68)
        Me.panelOne.TabIndex = 101
        '
        'cmb_Acc
        '
        Me.cmb_Acc.FormattingEnabled = True
        Me.cmb_Acc.Location = New System.Drawing.Point(13, 27)
        Me.cmb_Acc.Name = "cmb_Acc"
        Me.cmb_Acc.Size = New System.Drawing.Size(133, 24)
        Me.cmb_Acc.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(10, 7)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(143, 16)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Please Select Account"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(177, 7)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(117, 16)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Please Select File"
        '
        'browseFile
        '
        Me.browseFile.Location = New System.Drawing.Point(180, 28)
        Me.browseFile.Name = "browseFile"
        Me.browseFile.Size = New System.Drawing.Size(102, 23)
        Me.browseFile.TabIndex = 0
        Me.browseFile.Text = "Browse File"
        Me.browseFile.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 4)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(183, 16)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Strategy execution is paused."
        '
        'link_StartExecution
        '
        Me.link_StartExecution.ActiveLinkColor = System.Drawing.Color.Blue
        Me.link_StartExecution.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.link_StartExecution.Location = New System.Drawing.Point(192, 4)
        Me.link_StartExecution.Margin = New System.Windows.Forms.Padding(0, 0, 3, 0)
        Me.link_StartExecution.Name = "link_StartExecution"
        Me.link_StartExecution.Size = New System.Drawing.Size(338, 17)
        Me.link_StartExecution.TabIndex = 2
        Me.link_StartExecution.TabStop = True
        Me.link_StartExecution.Text = "Click here to Start Execution."
        '
        'ContextMenuStrip2
        '
        Me.ContextMenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MarkAsLevelExecutedToolStripMenuItem, Me.MarkAsTargetTradedToolStripMenuItem, Me.MarkAsNotExecutedToolStripMenuItem})
        Me.ContextMenuStrip2.Name = "ContextMenuStrip2"
        Me.ContextMenuStrip2.Size = New System.Drawing.Size(196, 70)
        '
        'MarkAsLevelExecutedToolStripMenuItem
        '
        Me.MarkAsLevelExecutedToolStripMenuItem.Name = "MarkAsLevelExecutedToolStripMenuItem"
        Me.MarkAsLevelExecutedToolStripMenuItem.Size = New System.Drawing.Size(195, 22)
        Me.MarkAsLevelExecutedToolStripMenuItem.Text = "Mark as Level Executed"
        '
        'MarkAsTargetTradedToolStripMenuItem
        '
        Me.MarkAsTargetTradedToolStripMenuItem.Name = "MarkAsTargetTradedToolStripMenuItem"
        Me.MarkAsTargetTradedToolStripMenuItem.Size = New System.Drawing.Size(195, 22)
        Me.MarkAsTargetTradedToolStripMenuItem.Text = "Mark as Target Traded"
        '
        'MarkAsNotExecutedToolStripMenuItem
        '
        Me.MarkAsNotExecutedToolStripMenuItem.Name = "MarkAsNotExecutedToolStripMenuItem"
        Me.MarkAsNotExecutedToolStripMenuItem.Size = New System.Drawing.Size(195, 22)
        Me.MarkAsNotExecutedToolStripMenuItem.Text = "Mark as Not Executed"
        '
        'col_Pos
        '
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.col_Pos.DefaultCellStyle = DataGridViewCellStyle1
        Me.col_Pos.HeaderText = "Pos"
        Me.col_Pos.Name = "col_Pos"
        Me.col_Pos.ReadOnly = True
        Me.col_Pos.ToolTipText = "Position Qty in Scrip"
        Me.col_Pos.Width = 55
        '
        'DGV
        '
        Me.DGV.AllowUserToAddRows = False
        Me.DGV.AllowUserToDeleteRows = False
        Me.DGV.AllowUserToResizeRows = False
        Me.DGV.BackgroundColor = System.Drawing.Color.WhiteSmoke
        Me.DGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGV.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.col_On, Me.col_SID, Me.col_Status, Me.col_Scrip, Me.col_LTP, Me.col_Quantity, Me.col_Side, Me.col_Account, Me.col_Price, Me.col_DES})
        Me.DGV.ContextMenuStrip = Me.ContextMenuStrip2
        Me.DGV.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DGV.Location = New System.Drawing.Point(0, 71)
        Me.DGV.Margin = New System.Windows.Forms.Padding(4)
        Me.DGV.MultiSelect = False
        Me.DGV.Name = "DGV"
        Me.DGV.RowHeadersVisible = False
        Me.DGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.DGV.Size = New System.Drawing.Size(612, 204)
        Me.DGV.TabIndex = 0
        '
        'col_On
        '
        Me.col_On.HeaderText = "On"
        Me.col_On.Name = "col_On"
        Me.col_On.ReadOnly = True
        Me.col_On.ToolTipText = "Strategy Running or Not"
        Me.col_On.Width = 30
        '
        'col_SID
        '
        Me.col_SID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.col_SID.DefaultCellStyle = DataGridViewCellStyle2
        Me.col_SID.HeaderText = "SID"
        Me.col_SID.Name = "col_SID"
        Me.col_SID.ReadOnly = True
        Me.col_SID.ToolTipText = "Strategy Identifier"
        Me.col_SID.Width = 55
        '
        'col_Status
        '
        Me.col_Status.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.col_Status.HeaderText = "Status"
        Me.col_Status.Name = "col_Status"
        Me.col_Status.ReadOnly = True
        Me.col_Status.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.col_Status.Width = 51
        '
        'col_Scrip
        '
        Me.col_Scrip.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.col_Scrip.HeaderText = "Scrip"
        Me.col_Scrip.Name = "col_Scrip"
        Me.col_Scrip.ReadOnly = True
        Me.col_Scrip.ToolTipText = "Scrip to Trade"
        Me.col_Scrip.Width = 64
        '
        'col_LTP
        '
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.col_LTP.DefaultCellStyle = DataGridViewCellStyle3
        Me.col_LTP.HeaderText = "LTP"
        Me.col_LTP.Name = "col_LTP"
        Me.col_LTP.ReadOnly = True
        Me.col_LTP.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.col_LTP.ToolTipText = "Last Traded Price"
        Me.col_LTP.Width = 60
        '
        'col_Quantity
        '
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.col_Quantity.DefaultCellStyle = DataGridViewCellStyle4
        Me.col_Quantity.HeaderText = "Quantity"
        Me.col_Quantity.Name = "col_Quantity"
        Me.col_Quantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.col_Quantity.ToolTipText = "Quantity"
        Me.col_Quantity.Width = 50
        '
        'col_Side
        '
        Me.col_Side.HeaderText = "Side"
        Me.col_Side.Name = "col_Side"
        '
        'col_Account
        '
        Me.col_Account.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        Me.col_Account.HeaderText = "Account"
        Me.col_Account.Name = "col_Account"
        Me.col_Account.ReadOnly = True
        Me.col_Account.Width = 81
        '
        'col_Price
        '
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle5.Format = "0.00"
        DataGridViewCellStyle5.NullValue = "0.00"
        Me.col_Price.DefaultCellStyle = DataGridViewCellStyle5
        Me.col_Price.HeaderText = "Price"
        Me.col_Price.Name = "col_Price"
        Me.col_Price.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.col_Price.ToolTipText = "StepTarget"
        Me.col_Price.Width = 50
        '
        'col_DES
        '
        Me.col_DES.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.col_DES.DefaultCellStyle = DataGridViewCellStyle6
        Me.col_DES.HeaderText = "DES"
        Me.col_DES.Name = "col_DES"
        Me.col_DES.ReadOnly = True
        Me.col_DES.ToolTipText = "Server Identifier"
        Me.col_DES.Width = 61
        '
        'ProgramTrading
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ClientSize = New System.Drawing.Size(612, 275)
        Me.Controls.Add(Me.DGV)
        Me.Controls.Add(Me.panel_StartStrategy)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "ProgramTrading"
        Me.Text = "Program Trading"
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.panel_StartStrategy.ResumeLayout(False)
        Me.panel_StartStrategy.PerformLayout()
        Me.panelOne.ResumeLayout(False)
        Me.panelOne.PerformLayout()
        Me.ContextMenuStrip2.ResumeLayout(False)
        CType(Me.DGV, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents DGV As CustomDGView
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents AddStrategyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteStrategyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SaveWatchlistToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents timer_SlowUpdate As System.Windows.Forms.Timer
    Friend WithEvents OthersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemoveExecutingStrategyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UpdateStrategyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents StartStrategyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StopStrategyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StrategyVersionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents panel_StartStrategy As System.Windows.Forms.Panel
    Friend WithEvents link_StartExecution As System.Windows.Forms.LinkLabel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ModifyStrategyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ShowJobbingStatusToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImportFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripMenuItem5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ParticularScripToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StartStrategiesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StopStrategiesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteStrategiesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ParticularAccountToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StartStrategiesPAccountToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StopStrategiesPAccountToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteStrategiesPAccountToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SquareoffStrategyCtrlQToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SquareOffStrategiesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SquareOffStrategiesToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContextMenuStrip2 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents MarkAsLevelExecutedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PauseStrategyCtrlPToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MarkAsTargetTradedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MarkAsNotExecutedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents panelOne As System.Windows.Forms.Panel
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents browseFile As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents cmb_Acc As System.Windows.Forms.ComboBox
    Friend WithEvents col_On As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents col_SID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_Status As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_Scrip As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_LTP As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_Side As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_Quantity As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_Price As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_Pos As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_Account As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_DES As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
