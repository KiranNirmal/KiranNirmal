<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AddStrategy
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.panel_Options = New System.Windows.Forms.FlowLayoutPanel()
        Me.panel_PrgTrd = New System.Windows.Forms.Panel()
        Me.btn_AddStrategy = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.txtBrowseFile = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lbl_SelectServer = New System.Windows.Forms.Label()
        Me.cmb_Account = New System.Windows.Forms.ComboBox()
        Me.cmb_Server = New System.Windows.Forms.ComboBox()
        Me.prgtrd_lbl_Account = New System.Windows.Forms.Label()
        Me.cmb_Direction = New System.Windows.Forms.ComboBox()
        Me.prgtrd_lbl_OrderType = New System.Windows.Forms.Label()
        Me.cmb_Exchange = New System.Windows.Forms.ComboBox()
        Me.prgtrd_lbl_Exchange = New System.Windows.Forms.Label()
        Me.txt_Symbol = New System.Windows.Forms.TextBox()
        Me.prgtrd_lbl_Symbol = New System.Windows.Forms.Label()
        Me.smartorder_lbl_Info = New System.Windows.Forms.Label()
        Me.panel_Final = New System.Windows.Forms.Panel()
        Me.lbl_Notice = New System.Windows.Forms.Label()
        Me.btn_Cancel = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.timer_UpdateUI = New System.Windows.Forms.Timer(Me.components)
        Me.panel_Options.SuspendLayout()
        Me.panel_PrgTrd.SuspendLayout()
        Me.SuspendLayout()
        '
        'panel_Options
        '
        Me.panel_Options.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panel_Options.Controls.Add(Me.panel_PrgTrd)
        Me.panel_Options.Location = New System.Drawing.Point(3, 2)
        Me.panel_Options.Name = "panel_Options"
        Me.panel_Options.Size = New System.Drawing.Size(392, 358)
        Me.panel_Options.TabIndex = 2
        '
        'panel_PrgTrd
        '
        Me.panel_PrgTrd.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panel_PrgTrd.Controls.Add(Me.btn_AddStrategy)
        Me.panel_PrgTrd.Controls.Add(Me.Button1)
        Me.panel_PrgTrd.Controls.Add(Me.txtBrowseFile)
        Me.panel_PrgTrd.Controls.Add(Me.Label2)
        Me.panel_PrgTrd.Controls.Add(Me.Label1)
        Me.panel_PrgTrd.Controls.Add(Me.lbl_SelectServer)
        Me.panel_PrgTrd.Controls.Add(Me.cmb_Account)
        Me.panel_PrgTrd.Controls.Add(Me.cmb_Server)
        Me.panel_PrgTrd.Controls.Add(Me.prgtrd_lbl_Account)
        Me.panel_PrgTrd.Controls.Add(Me.cmb_Direction)
        Me.panel_PrgTrd.Controls.Add(Me.prgtrd_lbl_OrderType)
        Me.panel_PrgTrd.Controls.Add(Me.cmb_Exchange)
        Me.panel_PrgTrd.Controls.Add(Me.prgtrd_lbl_Exchange)
        Me.panel_PrgTrd.Controls.Add(Me.txt_Symbol)
        Me.panel_PrgTrd.Controls.Add(Me.prgtrd_lbl_Symbol)
        Me.panel_PrgTrd.Location = New System.Drawing.Point(3, 3)
        Me.panel_PrgTrd.Name = "panel_PrgTrd"
        Me.panel_PrgTrd.Size = New System.Drawing.Size(378, 355)
        Me.panel_PrgTrd.TabIndex = 6
        '
        'btn_AddStrategy
        '
        Me.btn_AddStrategy.Location = New System.Drawing.Point(292, 306)
        Me.btn_AddStrategy.Margin = New System.Windows.Forms.Padding(15, 3, 3, 3)
        Me.btn_AddStrategy.Name = "btn_AddStrategy"
        Me.btn_AddStrategy.Size = New System.Drawing.Size(82, 25)
        Me.btn_AddStrategy.TabIndex = 1000
        Me.btn_AddStrategy.Text = "Add Strategy"
        Me.btn_AddStrategy.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(292, 51)
        Me.Button1.Margin = New System.Windows.Forms.Padding(15, 3, 3, 3)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(82, 25)
        Me.Button1.TabIndex = 1001
        Me.Button1.Text = "Load"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'txtBrowseFile
        '
        Me.txtBrowseFile.Location = New System.Drawing.Point(16, 54)
        Me.txtBrowseFile.Name = "txtBrowseFile"
        Me.txtBrowseFile.Size = New System.Drawing.Size(258, 22)
        Me.txtBrowseFile.TabIndex = 55
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(14, 23)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 16)
        Me.Label2.TabIndex = 54
        Me.Label2.Text = "Browse File"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(157, 109)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(27, 16)
        Me.Label1.TabIndex = 53
        Me.Label1.Text = "OR"
        '
        'lbl_SelectServer
        '
        Me.lbl_SelectServer.AutoSize = True
        Me.lbl_SelectServer.Location = New System.Drawing.Point(140, 276)
        Me.lbl_SelectServer.Name = "lbl_SelectServer"
        Me.lbl_SelectServer.Size = New System.Drawing.Size(44, 16)
        Me.lbl_SelectServer.TabIndex = 5
        Me.lbl_SelectServer.Text = "Server"
        '
        'cmb_Account
        '
        Me.cmb_Account.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmb_Account.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmb_Account.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_Account.FormattingEnabled = True
        Me.cmb_Account.Location = New System.Drawing.Point(14, 307)
        Me.cmb_Account.Name = "cmb_Account"
        Me.cmb_Account.Size = New System.Drawing.Size(114, 25)
        Me.cmb_Account.TabIndex = 5
        Me.ToolTip1.SetToolTip(Me.cmb_Account, "Trading Account Code provided by Exchange Member")
        '
        'cmb_Server
        '
        Me.cmb_Server.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmb_Server.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmb_Server.FormattingEnabled = True
        Me.cmb_Server.Location = New System.Drawing.Point(143, 307)
        Me.cmb_Server.Name = "cmb_Server"
        Me.cmb_Server.Size = New System.Drawing.Size(131, 24)
        Me.cmb_Server.Sorted = True
        Me.cmb_Server.TabIndex = 6
        Me.ToolTip1.SetToolTip(Me.cmb_Server, "Select Trading Server ")
        '
        'prgtrd_lbl_Account
        '
        Me.prgtrd_lbl_Account.AutoSize = True
        Me.prgtrd_lbl_Account.Location = New System.Drawing.Point(13, 276)
        Me.prgtrd_lbl_Account.Name = "prgtrd_lbl_Account"
        Me.prgtrd_lbl_Account.Size = New System.Drawing.Size(56, 16)
        Me.prgtrd_lbl_Account.TabIndex = 52
        Me.prgtrd_lbl_Account.Text = "Account"
        '
        'cmb_Direction
        '
        Me.cmb_Direction.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmb_Direction.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmb_Direction.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_Direction.FormattingEnabled = True
        Me.cmb_Direction.Items.AddRange(New Object() {"BULLISH", "BEARISH", "ALL"})
        Me.cmb_Direction.Location = New System.Drawing.Point(12, 240)
        Me.cmb_Direction.Name = "cmb_Direction"
        Me.cmb_Direction.Size = New System.Drawing.Size(114, 25)
        Me.cmb_Direction.TabIndex = 3
        Me.cmb_Direction.Text = "BULLISH"
        Me.ToolTip1.SetToolTip(Me.cmb_Direction, "Order Type e.g. Buy or Sell")
        '
        'prgtrd_lbl_OrderType
        '
        Me.prgtrd_lbl_OrderType.AutoSize = True
        Me.prgtrd_lbl_OrderType.Location = New System.Drawing.Point(13, 207)
        Me.prgtrd_lbl_OrderType.Name = "prgtrd_lbl_OrderType"
        Me.prgtrd_lbl_OrderType.Size = New System.Drawing.Size(59, 16)
        Me.prgtrd_lbl_OrderType.TabIndex = 51
        Me.prgtrd_lbl_OrderType.Text = "Direction"
        '
        'cmb_Exchange
        '
        Me.cmb_Exchange.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmb_Exchange.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmb_Exchange.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_Exchange.FormattingEnabled = True
        Me.cmb_Exchange.Items.AddRange(New Object() {"NSE", "NSEFO", "MCX"})
        Me.cmb_Exchange.Location = New System.Drawing.Point(13, 173)
        Me.cmb_Exchange.Name = "cmb_Exchange"
        Me.cmb_Exchange.Size = New System.Drawing.Size(83, 25)
        Me.cmb_Exchange.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.cmb_Exchange, "Exchange where Order shall be executed")
        '
        'prgtrd_lbl_Exchange
        '
        Me.prgtrd_lbl_Exchange.AutoSize = True
        Me.prgtrd_lbl_Exchange.Location = New System.Drawing.Point(11, 155)
        Me.prgtrd_lbl_Exchange.Name = "prgtrd_lbl_Exchange"
        Me.prgtrd_lbl_Exchange.Size = New System.Drawing.Size(66, 16)
        Me.prgtrd_lbl_Exchange.TabIndex = 50
        Me.prgtrd_lbl_Exchange.Text = "Exchange"
        '
        'txt_Symbol
        '
        Me.txt_Symbol.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txt_Symbol.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Symbol.Location = New System.Drawing.Point(98, 173)
        Me.txt_Symbol.MaxLength = 50
        Me.txt_Symbol.Name = "txt_Symbol"
        Me.txt_Symbol.Size = New System.Drawing.Size(176, 25)
        Me.txt_Symbol.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.txt_Symbol, "Scrip Symbol")
        '
        'prgtrd_lbl_Symbol
        '
        Me.prgtrd_lbl_Symbol.AutoSize = True
        Me.prgtrd_lbl_Symbol.Location = New System.Drawing.Point(98, 155)
        Me.prgtrd_lbl_Symbol.Name = "prgtrd_lbl_Symbol"
        Me.prgtrd_lbl_Symbol.Size = New System.Drawing.Size(52, 16)
        Me.prgtrd_lbl_Symbol.TabIndex = 45
        Me.prgtrd_lbl_Symbol.Text = "Symbol"
        '
        'smartorder_lbl_Info
        '
        Me.smartorder_lbl_Info.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.smartorder_lbl_Info.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.smartorder_lbl_Info.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.smartorder_lbl_Info.Location = New System.Drawing.Point(401, 2)
        Me.smartorder_lbl_Info.Name = "smartorder_lbl_Info"
        Me.smartorder_lbl_Info.Size = New System.Drawing.Size(240, 358)
        Me.smartorder_lbl_Info.TabIndex = 42
        Me.smartorder_lbl_Info.Text = "Explanation :"
        '
        'panel_Final
        '
        Me.panel_Final.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panel_Final.Location = New System.Drawing.Point(0, 389)
        Me.panel_Final.Margin = New System.Windows.Forms.Padding(10, 3, 3, 3)
        Me.panel_Final.Name = "panel_Final"
        Me.panel_Final.Size = New System.Drawing.Size(644, 33)
        Me.panel_Final.TabIndex = 999
        '
        'lbl_Notice
        '
        Me.lbl_Notice.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Notice.ForeColor = System.Drawing.Color.Red
        Me.lbl_Notice.Location = New System.Drawing.Point(3, 375)
        Me.lbl_Notice.Name = "lbl_Notice"
        Me.lbl_Notice.Size = New System.Drawing.Size(629, 38)
        Me.lbl_Notice.TabIndex = 998
        Me.lbl_Notice.Text = "Notice goes here."
        Me.lbl_Notice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn_Cancel
        '
        Me.btn_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btn_Cancel.Location = New System.Drawing.Point(-100, -100)
        Me.btn_Cancel.Name = "btn_Cancel"
        Me.btn_Cancel.Size = New System.Drawing.Size(24, 23)
        Me.btn_Cancel.TabIndex = 3
        Me.btn_Cancel.TabStop = False
        Me.btn_Cancel.Text = "X"
        Me.btn_Cancel.UseVisualStyleBackColor = True
        '
        'ToolTip1
        '
        Me.ToolTip1.AutoPopDelay = 5000
        Me.ToolTip1.InitialDelay = 100
        Me.ToolTip1.ReshowDelay = 100
        '
        'timer_UpdateUI
        '
        Me.timer_UpdateUI.Enabled = True
        '
        'AddStrategy
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.GhostWhite
        Me.CancelButton = Me.btn_Cancel
        Me.ClientSize = New System.Drawing.Size(644, 422)
        Me.Controls.Add(Me.lbl_Notice)
        Me.Controls.Add(Me.panel_Final)
        Me.Controls.Add(Me.smartorder_lbl_Info)
        Me.Controls.Add(Me.btn_Cancel)
        Me.Controls.Add(Me.panel_Options)
        Me.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.KeyPreview = True
        Me.Location = New System.Drawing.Point(100, 100)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "AddStrategy"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Add Strategy"
        Me.panel_Options.ResumeLayout(False)
        Me.panel_PrgTrd.ResumeLayout(False)
        Me.panel_PrgTrd.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents panel_Options As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents btn_Cancel As System.Windows.Forms.Button
    Friend WithEvents btn_AddStrategy As System.Windows.Forms.Button
    Friend WithEvents panel_Final As System.Windows.Forms.Panel
    Friend WithEvents lbl_Notice As System.Windows.Forms.Label
    Friend WithEvents cmb_Server As System.Windows.Forms.ComboBox
    Friend WithEvents lbl_SelectServer As System.Windows.Forms.Label
    Friend WithEvents smartorder_lbl_Info As System.Windows.Forms.Label
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents panel_PrgTrd As System.Windows.Forms.Panel
    Friend WithEvents cmb_Account As System.Windows.Forms.ComboBox
    Friend WithEvents prgtrd_lbl_Account As System.Windows.Forms.Label
    Friend WithEvents cmb_Direction As System.Windows.Forms.ComboBox
    Friend WithEvents prgtrd_lbl_OrderType As System.Windows.Forms.Label
    Friend WithEvents cmb_Exchange As System.Windows.Forms.ComboBox
    Friend WithEvents prgtrd_lbl_Exchange As System.Windows.Forms.Label
    Friend WithEvents txt_Symbol As System.Windows.Forms.TextBox
    Friend WithEvents prgtrd_lbl_Symbol As System.Windows.Forms.Label
    Friend WithEvents timer_UpdateUI As System.Windows.Forms.Timer
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtBrowseFile As System.Windows.Forms.TextBox
End Class
