Imports QuantX.IModule

Public Class AddStrategy

#Region "Veriables"
    Public MyParent As IModule

    Public AddStrategy As Boolean = False
    Public Exch As IHost.Exchanges
    Public Token As Int32
    Public DispName As String
    Public Direction As Int32
    Public Account As String
    Public Multiplier As Int32
    Public LotSize As Int32
    Public TickSize As Int32
    Public ServerIdx As Int16

    Private MyThreadSafe As IPropertySetter
#End Region

#Region "Forms Events"

    Private Sub btn_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Cancel.Click
        Me.Close()
    End Sub

    Private Sub AddStrategy_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = 13 And btn_AddStrategy.Text = "Add Strategy" Then
            Me.btn_AddStrategy_Click(Me, e)
        End If
    End Sub

    Private Sub AddStrategy_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lbl_Notice.Text = ""
        MyThreadSafe = MyParent.myHost.getThreadSafe(Me)

        Me.cmb_Server.Items.Clear()
        cmb_Server.Text = ""
        Me.cmb_Server.Items.AddRange(MyParent.myHost.get_DES_Names)
        If cmb_Server.Items.Count = 0 Then
            Me.lbl_Notice.Text = "DES not working / Strategy is not allowed."
            Exit Sub
        End If

        If MyParent.myHost.get_StaticVeriable("accounts") <> "" Then
            Dim tmpAccounts As String = MyParent.myHost.get_StaticVeriable("accounts")
            If tmpAccounts.EndsWith(",") Then
                tmpAccounts = tmpAccounts.Substring(0, tmpAccounts.Length - 1)
            End If
            Me.cmb_Account.Items.Clear()
            Me.cmb_Account.Items.AddRange(tmpAccounts.Split(","c))
        End If
    End Sub

    Private Sub btn_AddStrategy_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_AddStrategy.Click
        If Me.panel_Final.Visible = False Or Me.btn_AddStrategy.Enabled = False Then
            Exit Sub
        End If
        btn_AddStrategy.Enabled = False

        Dim t As New Threading.Thread(AddressOf ProcessAdd)
        t.Start()
    End Sub

    Private Sub ProcessAdd()
        Try
            If cmb_Exchange.SelectedIndex = -1 Then
                MyThreadSafe.SetCtrlProperty(lbl_Notice, "Text", "Provide valid Exchange")
                MyThreadSafe.CallCtrlMethod(cmb_Exchange, "Focus", Nothing)
                MyThreadSafe.SetCtrlProperty(btn_AddStrategy, "Enabled", True)
                Exit Sub
            End If
            If txt_Symbol.Text = "" Then
                MyThreadSafe.SetCtrlProperty(lbl_Notice, "Text", "Provide valid Symbol")
                MyThreadSafe.CallCtrlMethod(Me.txt_Symbol, "Focus", Nothing)
                MyThreadSafe.SetCtrlProperty(Me.btn_AddStrategy, "Enabled", True)
                Exit Sub
            End If
            If cmb_Direction.SelectedIndex < 0 Then
                MyThreadSafe.SetCtrlProperty(lbl_Notice, "Text", "Invalid Order Type")
                MyThreadSafe.CallCtrlMethod(Me.cmb_Direction, "Focus", Nothing)
                MyThreadSafe.SetCtrlProperty(Me.btn_AddStrategy, "Enabled", True)
                Exit Sub
            End If
            If cmb_Account.SelectedIndex < 0 Then
                MyThreadSafe.SetCtrlProperty(lbl_Notice, "Text", "Provide valid Account")
                MyThreadSafe.CallCtrlMethod(Me.cmb_Account, "Focus", Nothing)
                MyThreadSafe.SetCtrlProperty(Me.btn_AddStrategy, "Enabled", True)
                Exit Sub
            End If
            If cmb_Server.SelectedIndex < 0 Then
                MyThreadSafe.SetCtrlProperty(lbl_Notice, "Text", "Provide valid Server.")
                MyThreadSafe.CallCtrlMethod(Me.cmb_Server, "Focus", Nothing)
                MyThreadSafe.SetCtrlProperty(Me.btn_AddStrategy, "Enabled", True)
                Exit Sub
            End If

            Dim tmpSI As IHost.structScripInfo = MyParent.myHost.getScripInfo(Me.txt_Symbol.Text)
            If tmpSI.Token <= 0 Then
                For i As Integer = 0 To 100
                    tmpSI = MyParent.myHost.getScripInfo(Me.txt_Symbol.Text)
                    If tmpSI.Token > 0 Then
                        Exit For
                    End If
                    Threading.Thread.Sleep(100)
                    Application.DoEvents()
                Next
                If tmpSI.Token <= 0 Then
                    MyThreadSafe.SetCtrlProperty(lbl_Notice, "Text", "Invalid Scrip Provided!")
                    MyThreadSafe.CallCtrlMethod(cmb_Exchange, "Focus", Nothing)
                    MyThreadSafe.SetCtrlProperty(btn_AddStrategy, "Enabled", True)
                    Exit Sub
                End If
            End If

            MyParent.myHost.subscribe_LiveQuote(tmpSI.Exch, tmpSI.Token)

            Me.Exch = CType(tmpSI.Exch, IHost.Exchanges)
            Me.Token = tmpSI.Token
            Me.DispName = tmpSI.DispName
            Me.Multiplier = tmpSI.Multiplier
            Me.LotSize = tmpSI.LotSize
            Me.TickSize = tmpSI.TickSize
            Me.Direction = (cmb_Direction.SelectedIndex + 1)
            Me.Account = Me.cmb_Account.Text
            Me.ServerIdx = MyParent.myHost.get_DES_Status(Me.cmb_Server.Text).desSlot
            Me.AddStrategy = True

            MyThreadSafe.CallCtrlMethod(Me, "Close", Nothing)
        Catch ex As Exception
            MyParent.myHost.Add_Log_Host("ERROR", "Could not execute ProcessAddStrategy", ex.ToString)
        End Try
    End Sub
    Private Sub ProcessAddCSV(ByVal csvExchange As String, ByVal csvSymbol As String, ByVal csvDirection As String, ByVal csvAccount As String, ByVal csvServer As String)

        Try
            Dim tmpSI As IHost.structScripInfo = MyParent.myHost.getScripInfo(csvSymbol)
            If tmpSI.Token <= 0 Then
                For i As Integer = 0 To 100
                    tmpSI = MyParent.myHost.getScripInfo(csvSymbol)
                    If tmpSI.Token > 0 Then
                        Exit For
                    End If
                    Threading.Thread.Sleep(100)
                    Application.DoEvents()
                Next
                If tmpSI.Token <= 0 Then
                    MyThreadSafe.SetCtrlProperty(lbl_Notice, "Text", "Invalid Scrip Provided!")
                    ' MyThreadSafe.CallCtrlMethod(cmb_Exchange, "Focus", Nothing)
                    MyThreadSafe.SetCtrlProperty(btn_AddStrategy, "Enabled", True)
                    Exit Sub
                End If
            End If

            MyParent.myHost.subscribe_LiveQuote(tmpSI.Exch, tmpSI.Token)

            Me.Exch = CType(tmpSI.Exch, IHost.Exchanges)
            Me.Token = tmpSI.Token
            Me.DispName = tmpSI.DispName
            Me.Multiplier = tmpSI.Multiplier
            Me.LotSize = tmpSI.LotSize
            Me.TickSize = tmpSI.TickSize
            Me.Direction = (cmb_Direction.SelectedIndex + 1)
            Me.Account = csvAccount
            Me.ServerIdx = MyParent.myHost.get_DES_Status(csvServer).desSlot
            Me.AddStrategy = True

            MyThreadSafe.CallCtrlMethod(Me, "Close", Nothing)
        Catch ex As Exception
            MyParent.myHost.Add_Log_Host("ERROR", "Could not execute ProcessAddStrategy", ex.ToString)
        End Try
    End Sub
    Private Sub timer_UpdateUI_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles timer_UpdateUI.Tick
        If Not (Me.ActiveControl Is Nothing) Then
            smartorder_lbl_Info.Text = "Explanation : " + vbCrLf + vbCrLf + ToolTip1.GetToolTip(Me.ActiveControl).Replace("\n", vbCrLf)
        End If
    End Sub

    Private Sub ToolTip1_Popup1(ByVal sender As Object, ByVal e As System.Windows.Forms.PopupEventArgs) Handles ToolTip1.Popup
        Me.ToolTip1.SetToolTip(e.AssociatedControl, ToolTip1.GetToolTip(e.AssociatedControl).Replace("\n", vbCrLf))
    End Sub

    Private Sub txt_Symbol_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_Symbol.Enter
        If MyParent.myHost.ExchToInt(cmb_Exchange.Text) > 0 Then
            MyParent.myHost.setAutocomplete(CType(MyParent.myHost.ExchToInt(cmb_Exchange.Text), IHost.Exchanges), txt_Symbol)
        End If
    End Sub

    Private Sub txt_Symbol_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_Symbol.Leave
        If MyParent.myHost.ExchToInt(cmb_Exchange.Text) > 0 Then
            MyParent.myHost.removeAutocomplete(CType(MyParent.myHost.ExchToInt(cmb_Exchange.Text), IHost.Exchanges), txt_Symbol)
        End If
    End Sub

#End Region

    Private Sub txt_Symbol_TextChanged(sender As Object, e As EventArgs) Handles txt_Symbol.TextChanged

    End Sub

    Private Sub cmb_Server_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmb_Server.SelectedIndexChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim SR As StreamReader = New StreamReader(txtBrowseFile.Text)
        Dim line As String = SR.ReadLine()
        Dim strArray As String() = line.Split(","c)
        Dim dt As DataTable = New DataTable()
        Dim row As DataRow

        For Each s As String In strArray
            dt.Columns.Add(New DataColumn())
        Next

        Do
            line = SR.ReadLine
            If Not line = String.Empty Then
                row = dt.NewRow()
                row.ItemArray = line.Split(","c)
                dt.Rows.Add(row)
                ProcessAddCSV(CStr(row.ItemArray(0)), CStr(row.ItemArray(1)), CStr(row.ItemArray(2)), CStr(row.ItemArray(3)), CStr(row.ItemArray(4)))

                ' System.Console.WriteLine(row.ItemArray(0))
                'System.Console.WriteLine(line)
            Else
                Exit Do

            End If
        Loop
        Console.ReadKey(True)
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtBrowseFile.TextChanged
        
    End Sub

    Private Sub txtBrowseFile_Enter(sender As Object, e As EventArgs) Handles txtBrowseFile.Enter
        Dim fd As OpenFileDialog = New OpenFileDialog()

        fd.Title = "Open File Dialog"
        fd.InitialDirectory = "C:\"
        fd.Filter = "All files (*.*)|*.*|All files (*.*)|*.*"
        fd.FilterIndex = 2
        fd.RestoreDirectory = True

        If fd.ShowDialog() = DialogResult.OK Then
            txtBrowseFile.Text = fd.FileName
        End If
    End Sub

    Private Sub cmb_Account_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmb_Account.SelectedIndexChanged

    End Sub
End Class