Public Class CustomDGView
    Inherits DataGridView

    Public Sub New()
        Me.DoubleBuffered = True
    End Sub

    Protected Overloads Overrides Function ProcessDialogKey(ByVal keyData As Keys) As Boolean
        On Error Resume Next
        Select Case keyData
            Case Keys.Enter
                Dim col As Integer = Me.CurrentCell.ColumnIndex
                Dim row As Integer = Me.CurrentCell.RowIndex
                If Not (row = Me.NewRowIndex) Then
                    If col = (Me.Columns.Count - 1) Then
                        col = -1
                        row -= 1
                    End If
                    Me.CurrentCell = Me(col + 1, row)
                    Me.CurrentCell = Me(col, row)
                End If

                Return True

            Case Keys.Escape
                Return False

            Case Else
                Return MyBase.ProcessDialogKey(keyData)

        End Select
    End Function

    Protected Overloads Overrides Sub OnKeyDown(ByVal e As KeyEventArgs)
        Select Case e.KeyData
            Case Keys.Enter
                Dim col As Integer = Me.CurrentCell.ColumnIndex
                Dim row As Integer = Me.CurrentCell.RowIndex
                If Not (row = Me.NewRowIndex) Then
                    If col = (Me.Columns.Count - 1) Then
                        col = -1
                        row += 1
                    End If
                    Me.CurrentCell = Me(col + 1, row)
                End If
                e.Handled = True

            Case Keys.Escape

            Case Else
                MyBase.OnKeyDown(e)
        End Select
    End Sub

End Class



