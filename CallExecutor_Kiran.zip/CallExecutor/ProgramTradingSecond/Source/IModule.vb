Imports System.Net
Imports System.Net.Sockets

Public Class IModule
    Inherits MarshalByRefObject
    Implements QuantX.IPlugin

#Region "Module Veriables"
    Public myHost As QuantX.IHost
    Public myPath As String = ""
    Public MyIdx As Int16 = -1

    Private myStrInterface As ProgramTrading
#End Region

#Region "Module Properties"

    Public Property Module_Host() As IHost Implements IPlugin.Module_Host
        Get
            Return myHost
        End Get
        Set(ByVal value As IHost)
            myHost = value
        End Set
    End Property

    Public ReadOnly Property Module_Name() As String Implements IPlugin.Module_Name
        Get
            Return "IScalping"
        End Get
    End Property

    Public Function Module_Version() As Integer Implements IPlugin.Module_Version
        Return 12
    End Function

    Public Property Module_Path() As String Implements IPlugin.Module_Path
        Get
            Return myPath
        End Get
        Set(ByVal value As String)
            myPath = value
        End Set
    End Property

    Public Property Module_Idx() As Integer Implements IPlugin.Module_Idx
        Get
            Return MyIdx
        End Get
        Set(ByVal value As Integer)
            MyIdx = Convert.ToInt16(value)
        End Set
    End Property

    Public Property Module_NewFaceIdx() As Integer Implements IPlugin.Module_NewFaceIdx
        Get
            Return 0
        End Get
        Set(ByVal value As Integer)
        End Set
    End Property

    Public Function Module_Face(ByVal idx_Face As Integer) As System.Windows.Forms.Form Implements IPlugin.Module_Face
        Return myStrInterface
    End Function

    Public ReadOnly Property ShowInModulesList() As Boolean Implements IPlugin.ShowInModulesList
        Get
            Return False
        End Get
    End Property

#End Region

#Region "Basic Events"

    Public Sub Initialize() Implements IPlugin.Initialize
        'User Validation
        Try
            If myHost.get_StaticVeriable("strategies") Is Nothing Then
                Exit Sub
            End If
            If Not myHost.get_StaticVeriable("strategies").ToUpper.Contains(Me.Module_Name.ToUpper) Then
                Exit Sub
            End If
        Catch ex As Exception
            myHost.Add_Log_Host("ERROR", "'" + Me.Module_Name + "' Strategy not allowed for '" + myHost.Username + "'", ex.ToString)
            Exit Sub
        End Try

        'Server Validation
        Select Case myHost.ServerID.Replace(Chr(0), "")
            Case "ITPC-OM1LX2VCGR-Server", "ALAP-PC-Server", "WIN-T7UAF679FAD-Server"
            Case Else
                myHost.Add_Log_Host("ERROR", Me.Module_Name + " not allowed on this server.", "")
                Exit Sub
        End Select

        myStrInterface = New ProgramTrading
        myStrInterface.MyParent = Me
    End Sub

    Public Sub QuantX_Closing()

    End Sub

#End Region

#Region "Data Received Events"

    Public Sub Module_DataReceived(ByVal var_ModName As String, ByVal pkt() As Byte) Implements IPlugin.Module_DataReceived
    End Sub

    Public Sub Plugin_DataReceived(ByVal PID As Integer, ByVal pkt() As Byte) Implements IPlugin.Plugin_DataReceived

    End Sub

#End Region


End Class
