﻿Imports System.Threading
Imports System.Text.RegularExpressions

Public Class ProgramTrading
    Public MyParent As IModule
    Public PosTimeAndDate As Integer
    Public PosScript As Integer
    Public PosSide As Integer
    Public PosQuantity As Integer
    Public PosPrice As Integer



#Region "Veriables"

    Private th_ExecuteStrategy As Thread
    Private th_fileRead As Thread
    Private filePath As String
    Private timeWiseList As List(Of String)
    Private LoadedScript As Dictionary(Of String, String)


    Private lenMyStrategy As Integer = 999
    Private MyStrategy(lenMyStrategy) As strInfo
    Private IdxStrategy As Integer = 0 '0th Element is never used
    Private Structure strInfo
        Public fs As FileStream

        Public SID As Int32

        Public IsWorking As Boolean
        Public IsPaused As Boolean

        Public DispName As String
        Public Exch As Int32
        Public Token As Int32
        Public Multiplier As Int32
        Public LotSize As Int32
        Public TickSize As Int32
        Public DES As Int16

        Public Pos As Int32
        Public Quantity As Int32
        Public Price As Double
        Public side As String

        Public oid As Long
        Public Status As StrategyStatus
        Public Account As String

        Public tmp_OID As Int32
        Public tmp_M2M As Double

        Public TotalBuyValue As Int64
        Public TotalSellValue As Int64
        Public TotStrTrdQty As Int32

        Public ladder() As LadderDetails
        Public ladderDirection As StrategyDirection

        Public tmpSqOff_OID As Int32

        Public Structure LadderDetails
            Public Level As Int32
            Public LevelStatus As enmLevelStatus

            Public tmpLevel_OID As Int32
        End Structure

        Public Function GetBytes() As Byte()
            Dim ms As New MemoryStream
            Dim bw As New BinaryWriter(ms)

            bw.Write(SID)
            bw.Write(IsWorking)
            bw.Write(IsPaused)

            bw.Write(DispName)
            bw.Write(Exch)
            bw.Write(Token)
            bw.Write(Multiplier)
            bw.Write(LotSize)
            bw.Write(TickSize)
            bw.Write(DES)

            bw.Write(Pos)
            bw.Write(Quantity)
            bw.Write(Price)
            bw.Write(side)
            bw.Write(Convert.ToInt32(Status))
            bw.Write(Account)

            bw.Write(TotalBuyValue)
            bw.Write(TotalSellValue)

            If ladder Is Nothing Then
                bw.Write(Convert.ToInt32(0))
            Else
                bw.Write(Convert.ToInt32(ladder.Length))
                For Each strLD As LadderDetails In ladder
                    bw.Write(strLD.Level)
                    bw.Write(Convert.ToInt32(strLD.LevelStatus))
                Next
            End If

            bw.Write(Convert.ToInt32(ladderDirection))

            bw.Write(TotStrTrdQty)

            bw.Write(0)
            bw.Write(0)
            bw.Write(0)
            bw.Write(0)

            Return ms.ToArray
        End Function

        Public Sub ReadBytes(ByVal input() As Byte)
            Dim ms As New MemoryStream(input)
            Dim br As New BinaryReader(ms)

            SID = br.ReadInt32
            IsWorking = br.ReadBoolean
            IsPaused = br.ReadBoolean
            DispName = br.ReadString
            Exch = br.ReadInt32
            Token = br.ReadInt32
            Multiplier = br.ReadInt32
            LotSize = br.ReadInt32
            TickSize = br.ReadInt32
            DES = br.ReadInt16

            
            Pos = br.ReadInt32
            Quantity = br.ReadInt32
            Price = br.ReadDouble
            side = br.ReadString

            Status = CType(br.ReadInt32, StrategyStatus)
            Account = br.ReadString

            TotalBuyValue = br.ReadInt64
            TotalSellValue = br.ReadInt64

            Dim lenLadder As Int32 = (br.ReadInt32 - 1)
            ReDim ladder(lenLadder)
            For i As Integer = 0 To lenLadder
                Dim ld As LadderDetails
                ld.Level = br.ReadInt32()
                ld.LevelStatus = CType(br.ReadInt32, enmLevelStatus)
                ladder(i) = ld
            Next

            ladderDirection = CType(br.ReadInt32, StrategyDirection)
            TotStrTrdQty = br.ReadInt32

            br.Close()
            ms.Close()
        End Sub

        Public Sub ClearTempVeriables()
            tmp_OID = 0
            Pos = 0
            TotalBuyValue = 0
            TotalSellValue = 0
            TotStrTrdQty = 0
            Array.Clear(ladder, 0, ladder.Length)
        End Sub

        Public Sub ClearStrategyVeriables()
            ClearTempVeriables()

              End Sub

    End Structure

    Public Enum StrategyDirection
        Bullish = 1
        Bearish = 2
        All = 3
    End Enum

    Public Enum enmLevelStatus
        Initialized = 0
        Traded = 1
        TG_Traded = 2
        Executing = 3

        Execution_Cancelled = 9
        Execution_Error = 10
    End Enum

    Public Enum StrategyStatus
        Not_Working = 0

        Working = 1
        Working_Matching = 2
        Working_Jobbing = 3

        Executing_Accumulation = 4
        Executing_Levels = 5
        Executing_Target = 6
        Excecuted = 7

        SteppedOut_Range = 9
        Complete = 10

        Executing_SqoffAll = 11

        Error_Halted = 50
    End Enum

    Private lastSave As DateTime = Now
    Private LastTerminateRequest As DateTime = Now
    Private LastLogFlushed As DateTime = Now
    Private tmpError As Int32 = 0
    Private DetailsWindow_SID As Int32 = 0
#End Region

#Region "Forms Events"



    Private Sub btn_ClosePosition_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Me.dgv.Enabled = True
        Me.dgv.Focus()
    End Sub



    Private Sub ImportFileToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ImportFileToolStripMenuItem.Click
        Try
            Dim ofd As New OpenFileDialog
            ofd.Filter = "CSV File|*.CSV"
            ofd.CheckFileExists = True
            If ofd.ShowDialog <> Windows.Forms.DialogResult.OK Then
                Exit Sub
            End If

            Dim sr As New StreamReader(ofd.FileName)
            sr.ReadLine() 'Ignore Header
            While Not sr.EndOfStream
                Dim vals() As String = sr.ReadLine().Split(","c)
                If vals.Length < 6 Then
                    MyParent.myHost.Add_Log_Host("ERROR", "Invalid Parity Values Column Count.", "")
                    Exit Sub
                End If


                Dim tmpSID As Integer = getBlankSID()

                MyStrategy(tmpSID) = New strInfo
                ReDim MyStrategy(tmpSID).ladder(0)

                MyStrategy(tmpSID).IsWorking = False
                MyStrategy(tmpSID).IsPaused = False

                MyStrategy(tmpSID).DispName = vals(0)
                MyStrategy(tmpSID).Exch = Convert.ToInt32(vals(1))
                MyStrategy(tmpSID).Token = Convert.ToInt32(vals(2))
                MyStrategy(tmpSID).Multiplier = Convert.ToInt32(vals(3))
                MyStrategy(tmpSID).LotSize = Convert.ToInt32(vals(4))
                MyStrategy(tmpSID).TickSize = Convert.ToInt32(vals(5))
                MyStrategy(tmpSID).DES = Convert.ToByte(vals(6))

                MyStrategy(tmpSID).Status = StrategyStatus.Not_Working

                MyStrategy(tmpSID).Account = vals(17)

                addRow(tmpSID)
                UpdateRow(tmpSID)
            End While
            sendConfirmationPanel(-1, "STATUS", "{\colortbl;\red0\green0\blue150;}\cf1\b " + "file imported successfully." + " \b0")
        Catch ex As Exception
            MyParent.myHost.Add_Log_Host("ERROR", "Could not import 'Algo Watchlist File'!", ex.ToString)
        End Try
    End Sub

    Private Sub link_StartExecution_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles link_StartExecution.LinkClicked

    End Sub

    Private Sub StrategyInterface_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Text = MyParent.Module_Name + " " + MyParent.Module_Version.ToString

        LoadWatchlist()
        timer_SlowUpdate.Start()
        
        PosTimeAndDate = 0
        PosScript = 7
        PosSide = 10
        PosQuantity = 16
        PosPrice = 17


    End Sub

    Private Sub dgv_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgv.MouseDown
        Dim ht As DataGridView.HitTestInfo
        ht = Me.dgv.HitTest(e.X, e.Y)

        If ht.Type = DataGrid.HitTestType.Cell Then
            'Get the Index of Row which is being Dragged
            'We would use this Index on Drop to identify which Row was dragged and get the values from that row
            Dim rowIndexFromMouseDown As Integer = dgv.HitTest(e.X, e.Y).RowIndex
            Me.dgv.Rows(rowIndexFromMouseDown).Selected = True
            Me.dgv.Rows(rowIndexFromMouseDown).Cells(dgv.HitTest(e.X, e.Y).ColumnIndex).Selected = True
        End If
    End Sub

    Private Function SubmitStrategy(ByVal rowIdx As Integer, Optional ByVal ShowMsg As Boolean = False, Optional ByVal IsModify As Boolean = False, Optional ByVal IsSilent As Boolean = False) As Boolean
        Dim idxSID As Integer = Convert.ToInt32(Me.dgv.Rows(rowIdx).Cells("col_SID").Value.ToString)

        Dim tmpStartPointFrom As Double = 0

        '     If MyStrategy(idxSID).input_StartPointTo < MyStrategy(idxSID).input_SellBelow Or MyStrategy(idxSID).input_StartPointTo > MyStrategy(idxSID).input_BuyAbove Then
        'If Not IsSilent Then
        'sendConfirmationPanel(idxSID, "ERROR", "{\colortbl;\red190\green0\blue0;}\cf1\b " + "Start Point To(SPtT) cannot be less than Sell Above(SellBlw) and greater than Buy Above(BuyAbv). \b0")
        'End If
        'Me.dgv.Rows(rowIdx).Cells("col_StartPtT").Value = MyStrategy(idxSID).input_StartPointTo / MyStrategy(idxSID).Multiplier
        'Return False
        '   End If
        ' If MyStrategy(idxSID).input_StartPointFrom > MyStrategy(idxSID).input_StartPointTo Then
        'If Not IsSilent Then
        'sendConfirmationPanel(idxSID, "ERROR", "{\colortbl;\red190\green0\blue0;}\cf1\b " + "Start Point From(SPtF) cannot be greater than Start Point To(SPtT). \b0")
        'End If
        'Me.dgv.Rows(rowIdx).Cells("col_StartPtT").Value = MyStrategy(idxSID).input_StartPointTo / MyStrategy(idxSID).Multiplier
        'Return False
        ' End If
        'Return True
    End Function

    Private Sub timer_SlowUpdate_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles timer_SlowUpdate.Tick
        Try
            If Now.Subtract(lastSave).TotalSeconds > 60 Then
                lastSave = Now
                SaveS()
            End If

            Dim tmpRIdx As Integer = 0
            Dim tmpSID As Integer = 0
            Do
                If tmpRIdx > (Me.dgv.Rows.Count - 1) Then
                    Exit Do
                End If

                tmpSID = Convert.ToInt32(Me.dgv.Rows(tmpRIdx).Cells("col_SID").Value)
                If tmpSID > IdxStrategy Then
                    MyParent.myHost.Add_Log_Host("ERROR", "SID is greater than idxStrategy.", tmpSID.ToString + vbCrLf + "idxStrategy:" + IdxStrategy.ToString)
                End If

                Me.dgv.Rows(tmpRIdx).Cells("col_LTP").Value = MyParent.myHost.getQuote(MyStrategy(tmpSID).Exch, MyStrategy(tmpSID).Token).LTP / MyStrategy(tmpSID).Multiplier

                'MyStrategy(tmpSID).tmp_M2M = CInt((((MyStrategy(tmpSID).TotalSellValue - MyStrategy(tmpSID).TotalBuyValue) / MyStrategy(tmpSID).Multiplier) + ((MyParent.myHost.getQuote(MyStrategy(tmpSID).Exch, MyStrategy(tmpSID).Token).LTP * MyStrategy(tmpSID).Pos) / MyStrategy(tmpSID).Multiplier)))
                ' Me.dgv.Rows(tmpRIdx).Cells("col_M2M").Value = MyStrategy(tmpSID).tmp_M2M
                Me.DGV.Rows(tmpRIdx).Cells("col_Status").Value = MyStrategy(tmpSID).Status
                Me.DGV.Rows(tmpRIdx).Cells("col_DES").Value = MyParent.myHost.get_DES_Status(MyStrategy(tmpRIdx).DES).desName



                tmpRIdx += 1
            Loop

            'Auto Flush logs
            If Now.Subtract(LastLogFlushed).TotalSeconds > 5 Then
                LastLogFlushed = Now
                For idxSid As Integer = 1 To IdxStrategy
                    If Not MyStrategy(idxSid).fs Is Nothing Then
                        MyStrategy(idxSid).fs.Flush()
                    End If
                Next
            End If
        Catch ex As Exception
            If tmpError < 100 Then
                MyParent.myHost.Add_Log_Host("ERROR", "Could not update quotes.", ex.ToString)
                tmpError += 1
            End If
        End Try
    End Sub

    Private Sub dgv_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles dgv.KeyDown
        Dim isSilent As Boolean = False
        If sender Is Nothing Then
            isSilent = True
        End If

        Select Case e.KeyCode
            Case Keys.Enter
                e.Handled = True
                Exit Select

            Case Keys.A, Keys.Insert
                AddStrategyToolStripMenuItem_Click(Me, e)

            Case Keys.Delete
                DeleteScripToolStripMenuItem_Click(Me, e)

            Case Keys.N
                If Not e.Control Then
                    Exit Select
                End If
                If dgv.RowCount = 0 Then
                    sendConfirmationPanel(-1, "ERROR", "{\colortbl;\red190\green0\blue0;}\cf1\b " + "Strategy not found! \b0")
                    Exit Select
                End If
                Dim idxSID As Integer = Convert.ToInt32(dgv.CurrentRow.Cells("col_SID").Value.ToString)
                If MyStrategy(idxSID).IsWorking Then
                    sendConfirmationPanel(idxSID, "SID:" + idxSID.ToString, "{\colortbl;\red190\green0\blue0;}\cf1\b " + "Strategy already running! \b0")
                    Exit Sub
                End If

                ' If SubmitStrategy(Me.dgv.CurrentRow.Index, False, False, isSilent) Then
                'Delete old log if file is >786kb
                Try
                    If MyStrategy(idxSID).fs.Length > (1024 * 786) Then
                        Dim tmpFileName As String = MyStrategy(idxSID).fs.Name
                        MyStrategy(idxSID).fs.Close()
                        Dim fs As New FileStream(tmpFileName, FileMode.Truncate)
                        fs.Flush()
                        fs.Close()
                        MyStrategy(idxSID).fs = MyParent.myHost.Create_Log_File(tmpFileName)
                    End If
                Catch ex As Exception
                    MyParent.myHost.Add_Log_Host("CRASH", "Severe error while deleteing old log.", ex.ToString)
                End Try

                MyStrategy(idxSID).ClearTempVeriables()
                MyStrategy(idxSID).Status = StrategyStatus.Working
                MyStrategy(idxSID).IsWorking = True
                MyStrategy(idxSID).IsPaused = False

                If Not isSilent Then
                    sendConfirmationPanel(idxSID, "STATUS", "{\colortbl;\red0\green190\blue0;}\cf1\b " + "Strategy started successfully. Ver." + MyParent.Module_Version.ToString + " \b0")
                End If

                UpdateRow(idxSID)
                SaveS()
                'End If

            Case Keys.Q
                If Not e.Control Then
                    Exit Select
                End If
                If dgv.RowCount = 0 Then
                    sendConfirmationPanel(-1, "ERROR", "{\colortbl;\red190\green0\blue0;}\cf1\b " + "Strategy not found! \b0")
                    Exit Select
                End If
                Dim idxSID As Integer = Convert.ToInt32(dgv.CurrentRow.Cells("col_SID").Value.ToString)
                If Not MyStrategy(idxSID).IsWorking Then
                    sendConfirmationPanel(idxSID, "ERROR", "{\colortbl;\red180\green0\blue0;}\cf1\b " + "Strategy is not running! \b0")
                    Exit Sub
                End If
                Select Case MyStrategy(idxSID).Status
                    Case StrategyStatus.Working, StrategyStatus.Working_Matching, StrategyStatus.Working_Jobbing
                        If MyStrategy(idxSID).Pos = 0 Then
                            sendConfirmationPanel(idxSID, "ERROR", "{\colortbl;\red180\green0\blue0;}\cf1\b " + "No Position found! \b0")
                            Exit Sub
                        End If

                        MyStrategy(idxSID).tmpSqOff_OID = 0
                        MyStrategy(idxSID).Status = StrategyStatus.Executing_SqoffAll
                        UpdateRow(idxSID)
                        MyParent.myHost.Add_Log_File(MyStrategy(idxSID).fs, idxSID.ToString, "STATUS", "Strategy squareoff requested.", "")

                    Case Else
                        sendConfirmationPanel(idxSID, "ERROR", "{\colortbl;\red180\green0\blue0;}\cf1\b " + "Cannot update executing Strategy. \b0")
                        Exit Sub
                End Select

            Case Keys.P 'Pause Strategy
                If Not e.Control Then
                    Exit Select
                End If
                If dgv.RowCount = 0 Then
                    sendConfirmationPanel(-1, "ERROR", "{\colortbl;\red190\green0\blue0;}\cf1\b " + "Strategy not found! \b0")
                    Exit Select
                End If

                Dim idxSID As Integer = Convert.ToInt32(dgv.CurrentRow.Cells("col_SID").Value.ToString)
                If Not MyStrategy(idxSID).IsWorking Then
                    sendConfirmationPanel(idxSID, "ERROR", "{\colortbl;\red180\green0\blue0;}\cf1\b " + "Strategy is not running! \b0")
                    Exit Sub
                End If

                If MyStrategy(idxSID).IsPaused Then
                    MyStrategy(idxSID).IsPaused = False
                    sendConfirmationPanel(idxSID, "STATUS", "{\colortbl;\red0\green190\blue0;}\cf1\b " + "Strategy is working now. \b0")
                    MyParent.myHost.Add_Log_File(MyStrategy(idxSID).fs, idxSID.ToString, "STATUS", "Execution RESUMED.", "APPSTART")
                Else
                    MyStrategy(idxSID).IsPaused = True
                    If Not isSilent Then
                        sendConfirmationPanel(idxSID, "STATUS", "{\colortbl;\red0\green190\blue0;}\cf1\b " + "Strategy paused. \b0")
                    End If
                    MyParent.myHost.Add_Log_File(MyStrategy(idxSID).fs, idxSID.ToString, "STATUS", "Execution PAUSED.", "APPSTART")
                End If
                UpdateRow(idxSID)

            Case Keys.S
                If Not e.Control Then
                    Exit Select
                End If
                If dgv.RowCount = 0 Then
                    sendConfirmationPanel(-1, "ERROR", "{\colortbl;\red190\green0\blue0;}\cf1\b " + "Strategy not found! \b0")
                    Exit Select
                End If
                Dim idxSID As Integer = Convert.ToInt32(dgv.CurrentRow.Cells("col_SID").Value.ToString)
                If Not MyStrategy(idxSID).IsWorking Then
                    sendConfirmationPanel(idxSID, "ERROR", "{\colortbl;\red180\green0\blue0;}\cf1\b " + "Strategy is not running! \b0")
                    Exit Sub
                End If
                Select Case MyStrategy(idxSID).Status
                    Case StrategyStatus.Working, StrategyStatus.Working_Matching, StrategyStatus.Working_Jobbing
                        ' do nothing
                    Case Else
                        sendConfirmationPanel(idxSID, "ERROR", "{\colortbl;\red180\green0\blue0;}\cf1\b " + "Cannot update executing Strategy. \b0")
                        Exit Sub
                End Select

                If SubmitStrategy(Me.dgv.CurrentRow.Index, True, True, isSilent) Then
                    'MyParent.myHost.Add_Log_File(MyStrategy(idxSID).fs, idxSID.ToString, "STATUS", "Strategy updated successfully.", "Scrip:" + MyStrategy(idxSID).DispName.ToString + " Direction:" + MyStrategy(idxSID).strDirection.ToString + " StartPtF:" + MyStrategy(idxSID).input_StartPointFrom.ToString + " StartPtT:" + MyStrategy(idxSID).input_StartPointTo.ToString + " AQty:" + MyStrategy(idxSID).input_AccumQty.ToString + " ARange:" + MyStrategy(idxSID).input_AccumRange.ToString + " BuyAbove:" + MyStrategy(idxSID).input_BuyAbove.ToString + " SellBelow:" + MyStrategy(idxSID).input_SellBelow.ToString + " StepDiff:" + MyStrategy(idxSID).input_StepDiff.ToString + " StepQty:" + MyStrategy(idxSID).input_StepQty.ToString + " StepTgt:" + MyStrategy(idxSID).input_StepTarget.ToString)
                    SaveS()
                End If

            Case Keys.R
                If Not e.Control Then
                    Exit Select
                End If
                If dgv.RowCount = 0 Then
                    sendConfirmationPanel(-1, "ERROR", "{\colortbl;\red190\green0\blue0;}\cf1\b " + "Strategy not found! \b0")
                    Exit Select
                End If

                Dim idxSID As Integer = Convert.ToInt32(dgv.CurrentRow.Cells("col_SID").Value.ToString)
                If Not MyStrategy(idxSID).IsWorking Then
                    sendConfirmationPanel(idxSID, "ERROR", "{\colortbl;\red180\green0\blue0;}\cf1\b " + "Strategy is not running! \b0")
                    Exit Sub
                End If

                Select Case MyStrategy(idxSID).Status
                    Case StrategyStatus.Not_Working
                        sendConfirmationPanel(idxSID, "ERROR", "{\colortbl;\red180\green0\blue0;}\cf1\b " + "Strategy is not running! \b0")

                    Case StrategyStatus.Working, StrategyStatus.Working_Matching, StrategyStatus.Working_Jobbing, StrategyStatus.Complete
                        MyStrategy(idxSID).IsWorking = False
                        MyStrategy(idxSID).IsPaused = False
                        MyStrategy(idxSID).ClearStrategyVeriables()
                        MyStrategy(idxSID).Status = StrategyStatus.Not_Working

                        If Not isSilent Then
                            sendConfirmationPanel(idxSID, "STATUS", "{\colortbl;\red0\green180\blue0;}\cf1\b " + "Strategy stopped successfully. \b0")
                        End If
                        MyParent.myHost.Add_Log_File(MyStrategy(idxSID).fs, idxSID.ToString, "STATUS", "Strategy stopped.", "")

                        UpdateRow(idxSID)
                        SaveS()

                    Case Else
                        If Not isSilent Then
                            sendConfirmationPanel(idxSID, "ERROR", "{\colortbl;\red180\green0\blue0;}\cf1\b " + "Cannot remove working strategy! \b0")
                        End If
                End Select

            Case Keys.Z
                If Not e.Control Then
                    Exit Select
                End If
                If dgv.RowCount = 0 Then
                    sendConfirmationPanel(-1, "ERROR", "{\colortbl;\red190\green0\blue0;}\cf1\b " + "Strategy not found! \b0")
                    Exit Select
                End If

                Dim idxSID As Integer = Convert.ToInt32(dgv.CurrentRow.Cells("col_SID").Value.ToString)
                ' If Not MyStrategy(idxSID).IsWorking Then
                'sendConfirmationPanel(idxSID, "ERROR", "{\colortbl;\red180\green0\blue0;}\cf1\b " + "Strategy is not running! \b0")
                'Exit Sub
                ' End If

                If Now.Subtract(LastTerminateRequest).TotalSeconds < 4 Then
                    MyStrategy(idxSID).IsWorking = False
                    MyStrategy(idxSID).Status = StrategyStatus.Not_Working
                    sendConfirmationPanel(idxSID, "STATUS", "{\colortbl;\red0\green180\blue0;}\cf1\b " + "Strategy execution terminated by user. \b0")
                    MyStrategy(idxSID).ClearStrategyVeriables()
                    UpdateRow(idxSID)
                Else
                    sendConfirmationPanel(idxSID, "STATUS", "{\colortbl;\red0\green90\blue90;}\cf1\b " + "Request termination again to confirm. \b0")
                    LastTerminateRequest = Now
                End If

            Case Keys.M
                If Not e.Control Then
                    Exit Select
                End If
                If dgv.RowCount = 0 Then
                    sendConfirmationPanel(-1, "ERROR", "{\colortbl;\red190\green0\blue0;}\cf1\b " + "Strategy not found! \b0")
                    Exit Select
                End If
                If dgv.CurrentRow Is Nothing Then
                    sendConfirmationPanel(-1, "ERROR", "{\colortbl;\red190\green0\blue0;}\cf1\b " + "Kindly select strategy first!" + " \b0")
                    Exit Select
                End If

                AddStrategyToolStripMenuItem_Click(Nothing, Nothing)
        End Select
    End Sub



#Region "Context Menu"

    Private Sub AddStrategyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddStrategyToolStripMenuItem.Click
        Dim ad As New AddStrategy
        ad.MyParent = MyParent
        If sender Is Nothing Then
            Dim idxSID As Integer = Convert.ToInt32(dgv.CurrentRow.Cells("col_SID").Value.ToString)
            ad.cmb_Exchange.Text = CType(MyStrategy(idxSID).Exch, IHost.Exchanges).ToString
            ad.txt_Symbol.Text = MyStrategy(idxSID).DispName
            '        ad.cmb_Direction.SelectedIndex = (MyStrategy(idxSID).strDirection - 1)
            ad.cmb_Account.Text = MyStrategy(idxSID).Account
            ad.cmb_Server.Text = MyParent.myHost.get_DES_Status(MyStrategy(idxSID).DES).desName
        End If
        ad.ShowDialog()

        If ad.AddStrategy Then
            Dim tmpSID As Integer = getBlankSID()

            MyStrategy(tmpSID) = New strInfo
            ReDim MyStrategy(tmpSID).ladder(0)
            MyStrategy(tmpSID).IsPaused = False

            MyStrategy(tmpSID).DispName = ad.DispName
            MyStrategy(tmpSID).Exch = ad.Exch
            MyStrategy(tmpSID).Token = ad.Token
            MyStrategy(tmpSID).Multiplier = ad.Multiplier
            MyStrategy(tmpSID).LotSize = ad.LotSize
            MyStrategy(tmpSID).TickSize = ad.TickSize
            MyStrategy(tmpSID).DES = ad.ServerIdx

            'MyStrategy(tmpSID).strDirection = CType(ad.Direction, StrategyDirection)
            MyStrategy(tmpSID).Status = StrategyStatus.Not_Working

            MyStrategy(tmpSID).Account = ad.Account

            addRow(tmpSID)

            UpdateRow(tmpSID)

            Me.dgv.Focus()
            SaveS()
        End If
    End Sub

    Private Sub ModifyStrategyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ModifyStrategyToolStripMenuItem.Click
        dgv_KeyDown(Nothing, New KeyEventArgs(CType(131149, Keys)))
    End Sub

    Private Sub DeleteScripToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteStrategyToolStripMenuItem.Click
        If Me.dgv.CurrentRow Is Nothing Then
            sendConfirmationPanel(-1, "STAUS", "{\colortbl;\red190\green0\blue0;}\cf1\b " + "Kindly select valid strategy!." + " \b0")
            If Not sender Is Nothing Then
                MsgBox("Kindly select valid strategy!", MsgBoxStyle.Critical)
            End If
            Exit Sub
        End If

        Dim tmpSID As Integer = Convert.ToInt32(Me.dgv.CurrentRow.Cells("col_SID").Value)
        If MyStrategy(tmpSID).IsWorking Then
            sendConfirmationPanel(tmpSID, "STAUS", "{\colortbl;\red190\green0\blue0;}\cf1\b " + "Cannot delete running strategy." + " \b0")
            If Not sender Is Nothing Then
                MsgBox("Cannot delete running strategy!", MsgBoxStyle.Critical)
            End If
            Exit Sub
        End If
        If tmpSID < 0 Or tmpSID > IdxStrategy Then
            MyParent.myHost.Add_Log_Host("ERROR", "Invalid SID to delete strategy.", "SID:" + tmpSID.ToString)
            If Not sender Is Nothing Then
                MsgBox("Invalid SID to delete strategy.", MsgBoxStyle.Critical)
            End If
            Exit Sub
        End If

        If Not sender Is Nothing Then
            If MessageBox.Show("Are you sure to delete following strategy?" + vbCrLf + "Scrip: " + MyStrategy(tmpSID).DispName + vbCrLf + "SID: " + tmpSID.ToString, "Delete Confirmation", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) <> Windows.Forms.DialogResult.Yes Then
                Exit Sub
            End If
        End If

        sendConfirmationPanel(tmpSID, "STAUS", "{\colortbl;\red0\green190\blue0;}\cf1\b " + "Strategy deleted successfully." + " \b0")

        MyStrategy(tmpSID).DispName = ""
        MyStrategy(tmpSID).Token = 0
        MyStrategy(tmpSID).fs.Close()
        MyStrategy(tmpSID).fs = Nothing

        Me.dgv.Rows.Remove(dgv.CurrentRow)

        If Not sender Is Nothing Then
            SaveS()
        End If
    End Sub

    Private Sub SaveWatchlistToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveWatchlistToolStripMenuItem.Click
        If SaveS() Then
            sendConfirmationPanel(-1, MyParent.Module_Name, "{\colortbl;\red0\green190\blue0;}\cf1\b " + "Settings saved successfully." + " \b0")
        Else
            sendConfirmationPanel(-1, MyParent.Module_Name, "{\colortbl;\red190\green0\blue0;}\cf1\b " + "Error occured while saving settings." + " \b0")
        End If
    End Sub



    Private Sub RemoveExecutingStrategyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RemoveExecutingStrategyToolStripMenuItem.Click
        dgv_KeyDown(Nothing, New KeyEventArgs(CType(131162, Keys)))
    End Sub

    Private Sub StartStrategiesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StartStrategiesToolStripMenuItem.Click
        Try
            Dim outScrip As String = InputBox("All strategies belonging to Particular Scrip shall be started." + vbCrLf + "Kindly provide Scrip", "Start Particular Scrip Strategies", "")
            If outScrip Is Nothing Then
                Exit Sub
            End If
            If outScrip = "" Then
                Exit Sub
            End If
            If outScrip.Length > 50 Then
                Exit Sub
            End If

            MyParent.myHost.Add_Log_Host("STATUS", "Scrip - '" + outScrip + "' Starting All strategies.", "")
            sendConfirmationPanel(-1, "STATUS", "{\colortbl;\red0\green0\blue150;}\cf1\b " + "Scrip - " + outScrip + " Starting All strategies." + " \b0")

            For i As Integer = 0 To (Me.dgv.Rows.Count - 1)
                Dim idxSID As Integer = Convert.ToInt32(Me.dgv.Rows(i).Cells("col_SID").Value.ToString)
                If Not MyStrategy(idxSID).IsWorking Then
                    Continue For
                End If

                If outScrip.StartsWith("*") Then
                    If Not MyStrategy(idxSID).DispName.ToUpper.EndsWith(outScrip.ToUpper.Replace("*", "")) Then
                        Continue For
                    End If
                Else
                    If MyStrategy(idxSID).DispName.ToUpper <> outScrip.ToUpper Then
                        Continue For
                    End If
                End If

                MyParent.myHost.Add_Log_File(MyStrategy(idxSID).fs, idxSID.ToString, "STATUS", "'" + outScrip + "' START requested.", "")

                dgv.CurrentCell = dgv.Rows(i).Cells(0)
                dgv.Rows(i).Selected = True
                dgv_KeyDown(Nothing, New KeyEventArgs(CType(131150, Keys))) 'Ctrl+N
            Next
        Catch ex As Exception
            MyParent.myHost.Add_Log_Host("ERROR", "Critical error while Starting Particular Account.", ex.ToString)
        End Try
    End Sub

    Private Sub StopStrategiesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StopStrategiesToolStripMenuItem.Click
        Try
            Dim outScrip As String = InputBox("All strategies belonging to Scrip shall be stopped." + vbCrLf + "Kindly provide Scrip", "Stop Particular Scrip Strategies", "")
            If outScrip Is Nothing Then
                Exit Sub
            End If
            If outScrip = "" Then
                Exit Sub
            End If
            If outScrip.Length > 40 Then
                Exit Sub
            End If

            MyParent.myHost.Add_Log_Host("STATUS", "Scrip - " + outScrip + " Stopping All strategies.", "")
            sendConfirmationPanel(-1, "STATUS", "{\colortbl;\red0\green0\blue150;}\cf1\b " + "Scrip - " + outScrip + " Stopping All strategies." + " \b0")

            For i As Integer = 0 To (Me.dgv.Rows.Count - 1)
                Dim idxSID As Integer = Convert.ToInt32(Me.dgv.Rows(i).Cells("col_SID").Value.ToString)
                If Not MyStrategy(idxSID).IsWorking Then
                    Continue For
                End If

                If outScrip.StartsWith("*") Then
                    If Not MyStrategy(idxSID).DispName.ToUpper.EndsWith(outScrip.ToUpper.Replace("*", "")) Then
                        Continue For
                    End If
                Else
                    If MyStrategy(idxSID).DispName.ToUpper <> outScrip.ToUpper Then
                        Continue For
                    End If
                End If

                MyParent.myHost.Add_Log_File(MyStrategy(idxSID).fs, idxSID.ToString, "STATUS", "'" + outScrip + "' STOP requested.", "")

                dgv.CurrentCell = dgv.Rows(i).Cells(0)
                dgv.Rows(i).Selected = True
                dgv_KeyDown(Nothing, New KeyEventArgs(CType(131154, Keys))) 'Ctrl+R
            Next
        Catch ex As Exception
            MyParent.myHost.Add_Log_Host("ERROR", "Critical error while Stopping Particular Scrip.", ex.ToString)
        End Try
    End Sub

    Private Sub DeleteStrategiesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteStrategiesToolStripMenuItem.Click
        Try
            Dim outScrip As String = InputBox("All strategies belonging to Scrip shall be deleted." + vbCrLf + "Kindly provide Scrip", "Delete Particular Scrip Strategies", "")
            If outScrip Is Nothing Then
                Exit Sub
            End If
            If outScrip = "" Then
                Exit Sub
            End If
            If outScrip.Length > 40 Then
                Exit Sub
            End If

            MyParent.myHost.Add_Log_Host("STATUS", "Scrip - " + outScrip + " DELETING All strategies.", "")
            sendConfirmationPanel(-1, "STATUS", "{\colortbl;\red0\green0\blue150;}\cf1\b " + "Scrip - " + outScrip + " Stopping All strategies." + " \b0")

            For i As Integer = 0 To (Me.dgv.Rows.Count - 1)
                Dim idxSID As Integer = Convert.ToInt32(Me.dgv.Rows(i).Cells("col_SID").Value.ToString)
                If Not MyStrategy(idxSID).IsWorking Then
                    Continue For
                End If

                If outScrip.StartsWith("*") Then
                    If Not MyStrategy(idxSID).DispName.ToUpper.EndsWith(outScrip.ToUpper.Replace("*", "")) Then
                        Continue For
                    End If
                Else
                    If MyStrategy(idxSID).DispName.ToUpper <> outScrip.ToUpper Then
                        Continue For
                    End If
                End If

                dgv.CurrentCell = dgv.Rows(i).Cells(0)
                dgv.Rows(i).Selected = True
                DeleteScripToolStripMenuItem_Click(Nothing, Nothing)
            Next
            SaveS()
        Catch ex As Exception
            MyParent.myHost.Add_Log_Host("ERROR", "Critical error while Stopping Particular Scrip.", ex.ToString)
        End Try
    End Sub

    Private Sub StartStrategiesPAccountToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StartStrategiesPAccountToolStripMenuItem.Click
        Try
            Dim outAccount As String = InputBox("All strategies belonging to Particular Account shall be started." + vbCrLf + "Kindly provide Account", "Start Particular Account Strategies", "")
            If outAccount Is Nothing Then
                Exit Sub
            End If
            If outAccount = "" Then
                Exit Sub
            End If
            If outAccount.Length > 50 Then
                Exit Sub
            End If

            MyParent.myHost.Add_Log_Host("STATUS", "Account - '" + outAccount + "' Starting All strategies.", "")
            sendConfirmationPanel(-1, "STATUS", "{\colortbl;\red0\green0\blue150;}\cf1\b " + "Account - " + outAccount + " Starting All strategies." + " \b0")

            For i As Integer = 0 To (Me.dgv.Rows.Count - 1)
                Dim idxSID As Integer = Convert.ToInt32(Me.dgv.Rows(i).Cells("col_SID").Value.ToString)
                If Not MyStrategy(idxSID).IsWorking Then
                    Continue For
                End If

                If MyStrategy(idxSID).Account.ToUpper <> outAccount.ToUpper Then
                    Continue For
                End If


                MyParent.myHost.Add_Log_File(MyStrategy(idxSID).fs, idxSID.ToString, "STATUS", "'" + outAccount + "' START requested.", "")

                dgv.CurrentCell = dgv.Rows(i).Cells(0)
                dgv.Rows(i).Selected = True
                dgv_KeyDown(Nothing, New KeyEventArgs(CType(131150, Keys))) 'Ctrl+N
            Next
        Catch ex As Exception
            MyParent.myHost.Add_Log_Host("ERROR", "Critical error while Starting Particular Account.", ex.ToString)
        End Try
    End Sub

    Private Sub StopStrategiesPAccountToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StopStrategiesPAccountToolStripMenuItem.Click
        Try
            Dim outAccount As String = InputBox("All strategies belonging to Account shall be stopped." + vbCrLf + "Kindly provide Account", "Stop Particular Account Strategies", "")
            If outAccount Is Nothing Then
                Exit Sub
            End If
            If outAccount = "" Then
                Exit Sub
            End If
            If outAccount.Length > 40 Then
                Exit Sub
            End If

            MyParent.myHost.Add_Log_Host("STATUS", "Account - " + outAccount + " Stopping All strategies.", "")
            sendConfirmationPanel(-1, "STATUS", "{\colortbl;\red0\green0\blue150;}\cf1\b " + "Account - " + outAccount + " Stopping All strategies." + " \b0")

            For i As Integer = 0 To (Me.dgv.Rows.Count - 1)
                Dim idxSID As Integer = Convert.ToInt32(Me.dgv.Rows(i).Cells("col_SID").Value.ToString)
                If Not MyStrategy(idxSID).IsWorking Then
                    Continue For
                End If

                If outAccount.StartsWith("*") Then
                    If Not MyStrategy(idxSID).Account.ToUpper.EndsWith(outAccount.ToUpper.Replace("*", "")) Then
                        Continue For
                    End If
                Else
                    If MyStrategy(idxSID).Account.ToUpper <> outAccount.ToUpper Then
                        Continue For
                    End If
                End If

                MyParent.myHost.Add_Log_File(MyStrategy(idxSID).fs, idxSID.ToString, "STATUS", "'" + outAccount + "' STOP requested.", "")

                dgv.CurrentCell = dgv.Rows(i).Cells(0)
                dgv.Rows(i).Selected = True
                dgv_KeyDown(Nothing, New KeyEventArgs(CType(131154, Keys))) 'Ctrl+R
            Next
        Catch ex As Exception
            MyParent.myHost.Add_Log_Host("ERROR", "Critical error while Stopping Particular Account.", ex.ToString)
        End Try
    End Sub

    Private Sub DeleteStrategiesPAccountToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteStrategiesPAccountToolStripMenuItem.Click
        Try
            Dim outAccount As String = InputBox("All strategies belonging to Account shall be deleted." + vbCrLf + "Kindly provide Account", "Delete Particular Account Strategies", "")
            If outAccount Is Nothing Then
                Exit Sub
            End If
            If outAccount = "" Then
                Exit Sub
            End If
            If outAccount.Length > 40 Then
                Exit Sub
            End If

            MyParent.myHost.Add_Log_Host("STATUS", "Account - " + outAccount + " DELETING All strategies.", "")
            sendConfirmationPanel(-1, "STATUS", "{\colortbl;\red0\green0\blue150;}\cf1\b " + "Account - " + outAccount + " Stopping All strategies." + " \b0")

            For i As Integer = 0 To (Me.dgv.Rows.Count - 1)
                Dim idxSID As Integer = Convert.ToInt32(Me.dgv.Rows(i).Cells("col_SID").Value.ToString)
                If Not MyStrategy(idxSID).IsWorking Then
                    Continue For
                End If

                If outAccount.StartsWith("*") Then
                    If Not MyStrategy(idxSID).DispName.ToUpper.EndsWith(outAccount.ToUpper.Replace("*", "")) Then
                        Continue For
                    End If
                Else
                    If MyStrategy(idxSID).DispName.ToUpper <> outAccount.ToUpper Then
                        Continue For
                    End If
                End If

                dgv.CurrentCell = dgv.Rows(i).Cells(0)
                dgv.Rows(i).Selected = True
                DeleteScripToolStripMenuItem_Click(Nothing, Nothing)
            Next
            SaveS()
        Catch ex As Exception
            MyParent.myHost.Add_Log_Host("ERROR", "Critical error while Stopping Particular Account.", ex.ToString)
        End Try
    End Sub

    Private Sub SquareOffStrategiesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SquareOffStrategiesToolStripMenuItem.Click
        Try
            Dim outAccount As String = InputBox("All strategies belonging to Account shall be squared off." + vbCrLf + "Kindly provide Account", "Square Off Particular Account Strategies", "")
            If outAccount Is Nothing Then
                Exit Sub
            End If
            If outAccount = "" Then
                Exit Sub
            End If
            If outAccount.Length > 40 Then
                Exit Sub
            End If

            MyParent.myHost.Add_Log_Host("STATUS", "Account - " + outAccount + " Square Off All strategies.", "")
            sendConfirmationPanel(-1, "STATUS", "{\colortbl;\red0\green0\blue150;}\cf1\b " + "Account - " + outAccount + " Square Off All strategies." + " \b0")

            For i As Integer = 0 To (Me.dgv.Rows.Count - 1)
                Dim idxSID As Integer = Convert.ToInt32(Me.dgv.Rows(i).Cells("col_SID").Value.ToString)
                If Not MyStrategy(idxSID).IsWorking Then
                    Continue For
                End If

                If outAccount.StartsWith("*") Then
                    If Not MyStrategy(idxSID).Account.ToUpper.EndsWith(outAccount.ToUpper.Replace("*", "")) Then
                        Continue For
                    End If
                Else
                    If MyStrategy(idxSID).Account.ToUpper <> outAccount.ToUpper Then
                        Continue For
                    End If
                End If

                MyParent.myHost.Add_Log_File(MyStrategy(idxSID).fs, idxSID.ToString, "STATUS", "'" + outAccount + "' Square Off requested.", "")

                dgv.CurrentCell = dgv.Rows(i).Cells(0)
                dgv.Rows(i).Selected = True
                dgv_KeyDown(Nothing, New KeyEventArgs(CType(131153, Keys))) 'Ctrl+Q
            Next
        Catch ex As Exception
            MyParent.myHost.Add_Log_Host("ERROR", "Critical error while Suareoff Particular Account.", ex.ToString)
        End Try
    End Sub

    Private Sub SquareOffStrategiesToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SquareOffStrategiesToolStripMenuItem1.Click
        Try
            Dim outScrip As String = InputBox("All strategies belonging to Scrip shall be squared off." + vbCrLf + "Kindly provide Scrip", "SquareOff Particular Scrip Strategies", "")
            If outScrip Is Nothing Then
                Exit Sub
            End If
            If outScrip = "" Then
                Exit Sub
            End If
            If outScrip.Length > 40 Then
                Exit Sub
            End If

            MyParent.myHost.Add_Log_Host("STATUS", "Scrip - " + outScrip + " SquareOff All strategies.", "")
            sendConfirmationPanel(-1, "STATUS", "{\colortbl;\red0\green0\blue150;}\cf1\b " + "Scrip - " + outScrip + " SquareOff All strategies." + " \b0")

            For i As Integer = 0 To (Me.dgv.Rows.Count - 1)
                Dim idxSID As Integer = Convert.ToInt32(Me.dgv.Rows(i).Cells("col_SID").Value.ToString)
                If Not MyStrategy(idxSID).IsWorking Then
                    Continue For
                End If

                If outScrip.StartsWith("*") Then
                    If Not MyStrategy(idxSID).DispName.ToUpper.EndsWith(outScrip.ToUpper.Replace("*", "")) Then
                        Continue For
                    End If
                Else
                    If MyStrategy(idxSID).DispName.ToUpper <> outScrip.ToUpper Then
                        Continue For
                    End If
                End If

                MyParent.myHost.Add_Log_File(MyStrategy(idxSID).fs, idxSID.ToString, "STATUS", "'" + outScrip + "' SquareOff requested.", "")

                dgv.CurrentCell = dgv.Rows(i).Cells(0)
                dgv.Rows(i).Selected = True
                dgv_KeyDown(Nothing, New KeyEventArgs(CType(131153, Keys))) 'Ctrl+Q
            Next
        Catch ex As Exception
            MyParent.myHost.Add_Log_Host("ERROR", "Critical error while SquareOff Particular Scrip.", ex.ToString)
        End Try
    End Sub

    Private Sub UpdateStrategyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UpdateStrategyToolStripMenuItem.Click
        dgv_KeyDown(Nothing, New KeyEventArgs(CType(131155, Keys)))
    End Sub

    Private Sub PauseStrategyCtrlPToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PauseStrategyCtrlPToolStripMenuItem.Click
        dgv_KeyDown(Nothing, New KeyEventArgs(CType(131152, Keys))) 'Ctrl+P
    End Sub

    Private Sub StartStrategyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StartStrategyToolStripMenuItem.Click
        dgv_KeyDown(Nothing, New KeyEventArgs(CType(131150, Keys)))
    End Sub

    Private Sub StopStrategyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StopStrategyToolStripMenuItem.Click
        dgv_KeyDown(Nothing, New KeyEventArgs(CType(131154, Keys)))
    End Sub

    Private Sub SquareoffStrategyCtrlQToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SquareoffStrategyCtrlQToolStripMenuItem.Click
        dgv_KeyDown(Me, New KeyEventArgs(CType(131153, Keys))) 'Ctrl+Q
    End Sub

    Private Sub StrategyVersionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StrategyVersionToolStripMenuItem.Click
        MsgBox("Strategy Name : " + MyParent.Module_Name.ToString + vbCrLf + "Strategy Version : " + MyParent.Module_Version.ToString, MsgBoxStyle.Information)
    End Sub

#End Region

#End Region

#Region "Functions"

    Private Sub LoadWatchlist()
        Dim bt() As Byte = MyParent.myHost.bestDecompress(MyParent.myHost.Get_UserSetting(MyParent.Module_Name + "_Settings"))
        If bt Is Nothing Then
            Exit Sub
        End If
        If bt.Length <= 1 Then
            Exit Sub
        End If

        Dim showErr As Boolean = False
        Try
            Dim ms As New MemoryStream(bt)
            Dim br As New BinaryReader(ms)
            Dim btLen As Integer = bt.Length
            IdxStrategy = 0
            While br.BaseStream.Position < btLen
                Dim tmpSID As Integer = br.ReadInt32
                Dim tmpLen As Int32 = br.ReadInt32

                Dim rI As New strInfo
                ReDim rI.ladder(0)
                Try
                    rI.ReadBytes(br.ReadBytes(tmpLen))
                Catch ex As Exception
                    showErr = True
                    Continue While
                End Try
                MyStrategy(tmpSID) = rI

                If IdxStrategy < tmpSID Then
                    IdxStrategy = tmpSID
                End If
                'addRow(tmpSID)
                ' UpdateRow(tmpSID)
            End While
        Catch ex As Exception
            MyParent.myHost.Add_Log_Host("ERROR", "Could not load watchlist.", ex.ToString)
        End Try
        If showErr Then
            MyParent.myHost.Add_Log_Host("ERROR", "Watchlist is corrupt.", "Len:" + bt.Length.ToString)
        End If

    End Sub



    Private Sub UpdateRow(ByVal idxSID As Integer)
        If idxSID > IdxStrategy Or idxSID < 0 Then
            sendConfirmationPanel(idxSID, "ERROR", "{\colortbl;\red190\green0\blue0;}\cf1\b " + "Invalid SID to update. SID:" + idxSID.ToString + " \b0")
            MyParent.myHost.Add_Log_Host("ERROR", "Invalid SID to update.", "SID:" + idxSID.ToString + vbCrLf + "MaxSID:" + idxSID.ToString)
            Exit Sub
        End If
        For Each dr As DataGridViewRow In Me.dgv.Rows
            If dr.Cells("col_SID").Value.ToString = idxSID.ToString Then
                dr.Cells("col_On").Value = MyStrategy(idxSID).IsWorking

                'dr.Cells("col_Pos").Value = MyStrategy(idxSID).Pos.ToString
                ' dr.Cells("col_M2M").Value = (MyStrategy(idxSID).tmp_M2M / MyStrategy(idxSID).Multiplier).ToString
                dr.Cells("col_Status").Value = MyStrategy(idxSID).Status.ToString.Replace("_", " ")

                dr.Cells("col_Side").Value = MyStrategy(idxSID).side


                If MyStrategy(idxSID).IsPaused Then
                    dr.DefaultCellStyle.BackColor = Color.LightYellow
                    dr.Cells("col_Status").Value = "PAUSED"
                Else
                    Select Case MyStrategy(idxSID).Status
                        Case StrategyStatus.Not_Working
                            dr.DefaultCellStyle.BackColor = Color.WhiteSmoke
                        Case StrategyStatus.Executing_Accumulation
                            dr.DefaultCellStyle.BackColor = Color.LightPink
                        Case StrategyStatus.Working, StrategyStatus.Working_Matching, StrategyStatus.Working_Jobbing
                            dr.DefaultCellStyle.BackColor = Color.White
                        Case StrategyStatus.Error_Halted
                            dr.DefaultCellStyle.BackColor = Color.Red
                        Case StrategyStatus.Complete
                            dr.DefaultCellStyle.BackColor = Color.LightGreen
                        Case Else
                            dr.DefaultCellStyle.BackColor = Color.LightSteelBlue
                    End Select
                End If
            End If
        Next
    End Sub

    Private Function getLastSID() As Integer
        Dim mySID As Integer = 1
        Dim isFound As Boolean = True
        While isFound = True
            isFound = False
            For i As Integer = 0 To 999
                If MyStrategy(i).SID = mySID Then
                    mySID += 1
                    isFound = True
                    Exit For
                End If
            Next
        End While
        Return mySID
    End Function

    Private Sub addRow(ByVal idxSID As Integer)
        Try
            Dim dr As DataGridViewRow = Me.dgv.Rows(dgv.Rows.Add)

            If Not Directory.Exists(MyParent.myPath + "\Logs\") Then
                Directory.CreateDirectory(MyParent.myPath + "\Logs\")
            End If
            MyStrategy(idxSID).fs = MyParent.myHost.Create_Log_File(MyParent.myPath + "\Logs\" + MyParent.Module_Name + "-" + idxSID.ToString + ".qlg")

            dr.Cells("col_SID").Value = idxSID.ToString

            dr.Cells("col_Scrip").Value = MyStrategy(idxSID).DispName
            'dr.Cells("col_Direction").Value = MyStrategy(idxSID).strDirection.ToString

            'dr.Cells("col_AQty").Value = MyStrategy(idxSID).input_AccumQty.ToString
            'dr.Cells("col_AQty").Style.BackColor = Color.FromArgb(192, 255, 192)

            'dr.Cells("col_ARange").Value = (MyStrategy(idxSID).input_AccumRange / MyStrategy(idxSID).Multiplier).ToString
            'dr.Cells("col_ARange").Style.BackColor = Color.FromArgb(192, 255, 192)

            '            dr.Cells("col_BuyAbove").Value = (MyStrategy(idxSID).input_BuyAbove / MyStrategy(idxSID).Multiplier).ToString
            '           dr.Cells("col_BuyAbove").Style.BackColor = Color.FromArgb(192, 255, 255)

            dr.Cells("col_Quantity").Value = MyStrategy(idxSID).Quantity

            dr.Cells("col_Price").Value = MyStrategy(idxSID).Price
            dr.Cells("col_Side").Value = MyStrategy(idxSID).side


            ' dr.Cells("col_M2M").Value = (MyStrategy(idxSID).tmp_M2M / MyStrategy(idxSID).Multiplier).ToString
            ' dr.Cells("col_Pos").Value = MyStrategy(idxSID).input_SellBelow.ToString
            dr.Cells("col_Status").Value = MyStrategy(idxSID).Status.ToString.Replace("_", " ")
            dr.Cells("col_Account").Value = MyStrategy(idxSID).Account
            dr.Cells("col_DES").Value = MyParent.myHost.get_DES_Status(MyStrategy(idxSID).DES).desName

            MyParent.myHost.subscribe_LiveQuote(MyStrategy(idxSID).Exch, MyStrategy(idxSID).Token)
        Catch ex As Exception
            MyParent.myHost.Add_Log_Host("ERROR", "Could not add row.", ex.ToString)
            MsgBox("Could not add row.", MsgBoxStyle.Critical)
        End Try

    End Sub

    Private Function SaveS() As Boolean
        Try
            Dim ms As New MemoryStream
            Dim bw As New BinaryWriter(ms)

            For i As Integer = 0 To IdxStrategy
                If MyStrategy(i).DispName <> "" Then
                    bw.Write(Convert.ToInt32(i))
                    Dim bt() As Byte = MyStrategy(i).GetBytes
                    bw.Write(Convert.ToInt32(bt.Length))
                    bw.Write(bt)
                End If
            Next

            MyParent.myHost.Save_UserSetting(MyParent.Module_Name + "_Settings", MyParent.myHost.bestCompress(ms.ToArray))
        Catch ex As Exception
            MyParent.myHost.Add_Log_Host("ERROR", "Could not save settings.", ex.ToString)
            Return False
        End Try

        Return True
    End Function

    Private Function getDecimal(ByVal var_Price As Double, ByVal var_Multipler As Double) As Double
        Return Math.Round((var_Price / var_Multipler) - Convert.ToInt32(Math.Truncate(var_Price / var_Multipler)), Convert.ToInt32(var_Multipler.ToString.Replace("1", "").Length))
    End Function

    Private Function getBlankSID() As Integer
        For i As Integer = 1 To lenMyStrategy
            If MyStrategy(i).DispName = "" Then
                If IdxStrategy < i Then
                    IdxStrategy = i
                End If
                Return i
            End If
        Next
    End Function

    Public Sub sendConfirmationPanel(ByVal strIdx As Integer, ByVal Caption As String, ByVal Message As String)
        Dim ms As New MemoryStream
        Dim bw As New BinaryWriter(ms)
        bw.Write(BitConverter.GetBytes(Convert.ToInt16(0)))
        If strIdx > -1 Then
            Message += " SID:" + strIdx.ToString
        End If
        bw.Write(Encoding.UTF8.GetBytes(MyParent.Module_Name + "|" + Caption + "|" + Message))
        MyParent.myHost.sendModule(ms.ToArray, "Confirmation Panel")
        bw.Close()
        ms.Close()

        If strIdx > -1 And strIdx < IdxStrategy Then
            If MyStrategy(strIdx).fs Is Nothing Then
                Exit Sub
            End If

            MyParent.myHost.Add_Log_File(MyStrategy(strIdx).fs, strIdx.ToString, Caption, Regex.Replace(Message, "\{\*?\\[^{}]+}|[{}]|\\\n?[A-Za-z]+\n?(?:-?\d+)?[ ]?", ""), "Confirmation Message")
        End If
    End Sub

#End Region

#Region "Strategy Execution"

    Private Sub ExecuteStrategies()
        While MyParent.myHost.IsAppRunning
            Threading.Thread.Sleep(50)
            If Not MyParent.myHost.ORMS_Connected Then
                Continue While
            End If

            For idxSid As Integer = 1 To IdxStrategy
                Try
                    If Not MyStrategy(idxSid).IsWorking Then
                        Continue For
                    End If
                    If MyStrategy(idxSid).IsPaused Then
                        Continue For
                    End If

                    Select Case MyStrategy(idxSid).Status
                        Case StrategyStatus.Working
                            ''Placing Order 

                            sendConfirmationPanel(-1, "STATUS", "{\colortbl;\red10\green0\blue0;}\cf1\b " + "------- WORKING -------")

                            Dim Oaction As IHost.OrdAction
                            If (MyStrategy(idxSid).side.ToUpper.Equals("LONG")) Then
                                Oaction = IHost.OrdAction.Buy
                            Else
                                Oaction = IHost.OrdAction.Sell
                            End If
                            Dim price As Double
                            price = MyStrategy(idxSid).Price

                            Dim OrderType As IHost.OrderType

                            If (price = 0) Then
                                OrderType = IHost.OrderType.Market
                            Else
                                OrderType = IHost.OrderType.Limit
                            End If


                            Dim qty As Integer
                            qty = MyStrategy(idxSid).Quantity

                            MyStrategy(idxSid).oid = MyParent.myHost.SendOrder(Convert.ToInt16(MyStrategy(idxSid).DES),
                                                                               0, CShort(MyStrategy(idxSid).Exch),
                                                                               MyStrategy(idxSid).Token, Oaction,
                                                                               qty, 0, CInt(price), OrderType,
                                                                               IHost.OrderTerm.Day, MyStrategy(idxSid).Account,
                                                                               " ")

                            MyStrategy(idxSid).Status = StrategyStatus.Excecuted

                        Case StrategyStatus.Working_Matching

                        Case StrategyStatus.Executing_Accumulation

                        Case StrategyStatus.Working_Jobbing

                        Case StrategyStatus.Excecuted

                        Case StrategyStatus.Executing_SqoffAll

                        Case StrategyStatus.Executing_Levels

                        Case StrategyStatus.Executing_Target


                    End Select
                Catch ex As Exception
                    MyStrategy(idxSid).Status = StrategyStatus.Error_Halted
                    MyParent.myHost.Add_Log_File(MyStrategy(idxSid).fs, idxSid.ToString, "ERROR", "Critical error in execution.", ex.ToString)
                End Try
            Next
        End While
    End Sub

#End Region



#Region "Context Levels"

    
#End Region

    Private Sub dgvLadder_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)

    End Sub

    Private Sub dgv_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentClick

    End Sub

    'Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
    ' On Error Resume Next
    'th_ExecuteStrategy.Abort()

    'th_ExecuteStrategy = New Threading.Thread(AddressOf ExecuteStrategies)
    'th_ExecuteStrategy.Start()


    'Label1.Visible = False
    'LinkLabel1.Visible = False
    'panel_StartStrategy.Visible = False


    'For idxSid As Integer = 1 To IdxStrategy
    'If MyStrategy(idxSid).IsWorking Then
    'MyParent.myHost.Add_Log_File(MyStrategy(idxSid).fs, idxSid.ToString, "STATUS", "Execution STARTED.", "APPSTART")
    'Else
    'MyStrategy(idxSid).Status = StrategyStatus.Working_Matching

    'End If

    'UpdateRow(idxSid)
    ' Next


    'End Sub
    Private Sub startStrategy()
        On Error Resume Next
        th_ExecuteStrategy.Abort()

        th_ExecuteStrategy = New Threading.Thread(AddressOf ExecuteStrategies)
        th_ExecuteStrategy.Start()

        'Label1.Visible = False
        'LinkLabel1.Visible = False
        'panel_StartStrategy.Visible = False
        For idxSid As Integer = 1 To IdxStrategy
            If MyStrategy(idxSid).IsWorking Then
                MyParent.myHost.Add_Log_File(MyStrategy(idxSid).fs, idxSid.ToString, "STATUS", "Execution STARTED.", "APPSTART")
            Else
                MyStrategy(idxSid).Status = StrategyStatus.Working_Matching

            End If

            UpdateRow(idxSid)
        Next

    End Sub



    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub panel_StartStrategy_Paint(sender As Object, e As PaintEventArgs) Handles panel_StartStrategy.Paint

    End Sub

    Private Sub readFileNow()
        Try
            While (True)
                Try

                    Dim sr As New StreamReader(filePath)
                    'sr.ReadLine() 'Ignore Header
                    While Not sr.EndOfStream
                        Dim rowString As String
                        Dim data() As String

                        rowString = Regex.Replace(sr.ReadLine().ToString, "\s", ",")
                        data = rowString.Split(New Char() {","c})
                        Dim TimeNDate As String
                        Dim scriptName As String
                        Dim Side As String
                        Dim _qty As Integer
                        Dim _price As Double
                        TimeNDate = ""
                        scriptName = ""
                        Side = ""

                        Try
                            TimeNDate = data(PosTimeAndDate).ToString + data(PosTimeAndDate + 1).ToString
                            scriptName = data(PosScript).ToString
                            Side = data(PosSide).ToString
                            _qty = Integer.Parse(data(PosQuantity))
                            _price = Integer.Parse(data(PosPrice))
                            'sendConfirmationPanel(-1, "STATUS", "{\colortbl;\red0\green0\blue100;}\cf1\b " + TimeNDate + "-" + scriptName + "-" + Side)

                        Catch ex As Exception

                        End Try
                        If (timeWiseList.Count = 0) Then
                            timeWiseList.Add(TimeNDate)
                            sendConfirmationPanel(-1, "STATUS", "{\colortbl;\red10\green0\blue0;}\cf1\b " + TimeNDate + "-" + scriptName + "-" + Side)
                            createInstance(TimeNDate, scriptName, Side, _price, _qty)
                        Else
                            If Not (timeWiseList.Contains(TimeNDate)) Then
                                timeWiseList.Add(TimeNDate)
                                sendConfirmationPanel(-1, "STATUS", "{\colortbl;\red10\green0\blue0;}\cf1\b " + TimeNDate + "-" + scriptName + "-" + Side)
                                createInstance(TimeNDate, scriptName, Side, _price, _qty)
                            End If
                        End If
                    End While
                    sr.Close()

                Catch ex As Exception

                End Try
                Thread.Sleep(5000)
            End While
        Catch ex As Exception

        End Try
    End Sub
    Private Sub createInstance(time As String, scriptName As String, side As String, price As Double, qty As Integer)
        Dim tmpSID As Integer
        Dim create As Boolean

        If (LoadedScript.Count = 0) Then
            tmpSID = getBlankSID()
            LoadedScript.Add(scriptName, tmpSID.ToString)
            create = True
        Else
            If Not (LoadedScript.ContainsKey(scriptName)) Then
                tmpSID = getBlankSID()
                LoadedScript.Add(scriptName, tmpSID.ToString)
                create = True
            Else
                create = False
                tmpSID = CInt(LoadedScript(scriptName))
                sendConfirmationPanel(-1, "STATUS", "{\colortbl;\red150\green0\blue0;}\cf1\b " + " Update SID " + LoadedScript(scriptName) + " SName:" + scriptName)
                MyStrategy(tmpSID).Status = StrategyStatus.Working
                'MyStrategy(tmpSID).Status = StrategyStatus.Working
                MyStrategy(tmpSID).Price = price
                MyStrategy(tmpSID).Quantity = qty
                MyStrategy(tmpSID).side = side
                MyStrategy(tmpSID).IsWorking = True
                MyStrategy(tmpSID).Account = cmb_Acc.Text

                UpdateRow(tmpSID)


            End If
        End If
        If (create) Then
            'Dim tmpSI As IHost.structScripInfo = MyParent.myHost.getScripInfo(scriptName + "EQ")
            Dim tmpSI As IHost.structScripInfo = MyParent.myHost.getScripInfo(scriptName)
            MyStrategy(tmpSID) = New strInfo
            ReDim MyStrategy(tmpSID).ladder(0)

            MyStrategy(tmpSID).IsWorking = False
            MyStrategy(tmpSID).IsPaused = False
            'MyStrategy(tmpSID).DispName = scriptName + "EQ"
            MyStrategy(tmpSID).DispName = scriptName

            If tmpSI.Token <= 0 Then
                For i As Integer = 0 To 100
                    ' tmpSI = MyParent.myHost.getScripInfo(scriptName + "EQ")
                    tmpSI = MyParent.myHost.getScripInfo(scriptName)
                    If tmpSI.Token > 0 Then
                        Exit For
                    End If
                    Threading.Thread.Sleep(100)
                    Application.DoEvents()
                Next
                If tmpSI.Token <= 0 Then
                    sendConfirmationPanel(-1, "STATUS", "{\colortbl;\red150\green0\blue0;}\cf1\b " + " InValid Script Provided " + scriptName + "EQ")
                    Exit Sub
                End If
            End If

            MyParent.myHost.subscribe_LiveQuote(tmpSI.Exch, tmpSI.Token)
            MyStrategy(tmpSID).Exch = CType(tmpSI.Exch, IHost.Exchanges)
            MyStrategy(tmpSID).Token = tmpSI.Token
            MyStrategy(tmpSID).DES = 3
            MyStrategy(tmpSID).Multiplier = tmpSI.Multiplier
            MyStrategy(tmpSID).LotSize = tmpSI.LotSize
            MyStrategy(tmpSID).TickSize = tmpSI.TickSize
            MyStrategy(tmpSID).Status = StrategyStatus.Working
            MyStrategy(tmpSID).Price = price
            MyStrategy(tmpSID).Quantity = qty
            MyStrategy(tmpSID).side = side
            MyStrategy(tmpSID).IsWorking = True
            MyStrategy(tmpSID).Account = cmb_Acc.Text


            addRow(tmpSID)
            UpdateRow(tmpSID)


        End If
    End Sub

    Private Sub browseFile_Click(sender As Object, e As EventArgs) Handles browseFile.Click
        On Error Resume Next
        If (cmb_Acc.Text.ToString.Trim.Equals("")) Then
            sendConfirmationPanel(-1, "STATUS", "{\colortbl;\red150\green0\blue0;}\cf1\b " + " Please Select Account First.")
            Return
        End If
        Dim ofd As New OpenFileDialog
        ' ofd.Filter = "QuantX Dat File|*.csv"
        ofd.InitialDirectory = MyParent.myPath
        If ofd.ShowDialog <> Windows.Forms.DialogResult.OK Then
            Exit Sub
        End If

        timeWiseList = New List(Of String)
        LoadedScript = New Dictionary(Of String, String)

        filePath = ofd.FileName
        th_fileRead.Abort()
        th_fileRead = New Threading.Thread(AddressOf readFileNow)
        th_fileRead.Start()

        startStrategy()
      

        ''------------------------------------------------------------------------


    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmb_Acc.SelectedIndexChanged

    End Sub

    Private Sub cmb_Acc_Enter(sender As Object, e As EventArgs) Handles cmb_Acc.Enter
        If MyParent.myHost.get_StaticVeriable("accounts") <> "" Then
            Dim tmpAccounts As String = MyParent.myHost.get_StaticVeriable("accounts")
            If tmpAccounts.EndsWith(",") Then
                tmpAccounts = tmpAccounts.Substring(0, tmpAccounts.Length - 1)
            End If
            Me.cmb_Acc.Items.Clear()
            Me.cmb_Acc.Items.AddRange(tmpAccounts.Split(","c))
        End If
    End Sub

    Private Sub DGV_CellContentClick_1(sender As Object, e As DataGridViewCellEventArgs) Handles DGV.CellContentClick

    End Sub

    Private Sub panelOne_Paint(sender As Object, e As PaintEventArgs) Handles panelOne.Paint

    End Sub
End Class
